# SEO Phase 1: Astro and Technical Foundation Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Replace the Vite SPA with a statically rendered Astro marketing site that preserves the existing design and provides complete technical SEO, analytics, and App Store conversion foundations.

**Architecture:** Astro renders the homepage and legal routes to static HTML. Shared Astro layouts own metadata and structured data; small JavaScript modules own App Store URL generation and failure-tolerant analytics; React remains available only for genuinely interactive islands.

**Tech Stack:** Astro 7.1.6, React 19.2.0, `@astrojs/react` 6.0.2, `@astrojs/sitemap` 3.7.3, `@astrojs/tailwind` 6.0.2, Tailwind CSS 3.4.19, Vitest 4.1.10, Lighthouse CI 0.15.1, Node.js 22.13.0, Plausible Analytics.

## Global Constraints

- Phase 0 exit gate must pass before starting this plan.
- Preserve the current dark visual identity, hero imagery, responsive layout, and static `dist/` deployment output.
- English remains the root language; Spanish and Catalan routes are not created in this phase.
- Primary CTA copy is `Download ManageState for iPhone`; do not add an email gate, account creation, or demo requirement.
- The canonical site is `https://managestate.app`; the App Store ID is `6751497970`.
- Render only evidence that passes `validateBaselineData`.
- Remove dead buttons, Vite branding, generated avatars, and unsupported adoption/security claims.
- Primary copy, metadata, links, and structured data must exist in static HTML without client JavaScript.
- Analytics failures must never block page rendering or App Store navigation.

---

### Task 1: Replace the Vite build with Astro and a test harness

**Files:**
- Modify: `landing-page/package.json`
- Modify: `landing-page/package-lock.json`
- Create: `landing-page/astro.config.mjs`
- Create: `landing-page/vitest.config.mjs`
- Modify: `landing-page/eslint.config.js`
- Delete: `landing-page/vite.config.js`
- Delete: `landing-page/index.html`
- Delete: `landing-page/src/main.jsx`

**Interfaces:**
- Consumes: static site URL `https://managestate.app` and existing Tailwind configuration.
- Produces: `npm run dev`, `npm run build`, `npm test`, `npm run lint`, and `npm run verify` for the Astro site.

- [ ] **Step 1: Add a failing configuration test**

```js
// landing-page/tests/config/astro-config.test.mjs
import { describe, expect, it } from 'vitest';
import config from '../../astro.config.mjs';

describe('Astro configuration', () => {
  it('builds the canonical static site', () => {
    expect(config.site).toBe('https://managestate.app');
    expect(config.output).toBe('static');
  });
});
```

- [ ] **Step 2: Install the pinned foundation dependencies**

Run:

```bash
cd landing-page
npm install astro@7.1.6 @astrojs/react@6.0.2 @astrojs/sitemap@3.7.3 @astrojs/tailwind@6.0.2 tailwindcss@3.4.19
npm install -D vitest@4.1.10 jsdom@30.0.1 @lhci/cli@0.15.1
npm uninstall vite @vitejs/plugin-react pdf-parse
```

Expected: lockfile updates without peer-dependency errors.

- [ ] **Step 3: Create Astro and Vitest configuration**

```js
// landing-page/astro.config.mjs
import { defineConfig } from 'astro/config';
import react from '@astrojs/react';
import sitemap from '@astrojs/sitemap';
import tailwind from '@astrojs/tailwind';

export default defineConfig({
  site: 'https://managestate.app',
  output: 'static',
  integrations: [react(), sitemap(), tailwind({ applyBaseStyles: false })],
  build: { format: 'directory' }
});
```

```js
// landing-page/vitest.config.mjs
import { defineConfig } from 'vitest/config';
export default defineConfig({ test: { environment: 'node', include: ['tests/**/*.test.mjs'] } });
```

Update scripts to:

```json
{
  "dev": "astro dev",
  "build": "astro build",
  "preview": "astro preview",
  "test": "vitest run",
  "lint": "eslint .",
  "check:baseline": "node scripts/seo/validate-baseline-data.mjs",
  "check:dist": "node scripts/seo/validate-dist.mjs",
  "verify": "npm run lint && npm test && npm run check:baseline && npm run build && npm run check:dist"
}
```

Retain `test:baseline`. Update ESLint globs to lint `js`, `jsx`, and `mjs`, ignore `dist`, `.astro`, and generated `.astro` cache files, and remove the Vite-only React Refresh preset.

- [ ] **Step 4: Remove Vite entry files and run the config test**

Run: `cd landing-page && npm test -- tests/config/astro-config.test.mjs`
Expected: PASS.

- [ ] **Step 5: Commit the build migration**

```bash
git add landing-page/package.json landing-page/package-lock.json landing-page/astro.config.mjs landing-page/vitest.config.mjs landing-page/eslint.config.js landing-page/tests/config/astro-config.test.mjs
git rm landing-page/vite.config.js landing-page/index.html landing-page/src/main.jsx
git commit -m "build(landing): migrate Vite foundation to Astro"
```

### Task 2: Implement the canonical SEO model and base layout

**Files:**
- Create: `landing-page/src/lib/seo.js`
- Create: `landing-page/src/layouts/BaseLayout.astro`
- Create: `landing-page/src/components/SeoHead.astro`
- Create: `landing-page/src/styles/global.css`
- Create: `landing-page/tests/seo/seo.test.mjs`
- Modify: `landing-page/src/data/site.json`

**Interfaces:**
- Consumes: `site.json` and page props `{ title, description, path, lang, image, alternates, schemas, noindex }`.
- Produces: `canonicalUrl(path)`, `buildPageMeta(input)`, and static `<head>` metadata for every page.

- [ ] **Step 1: Write failing metadata tests**

```js
import { describe, expect, it } from 'vitest';
import { buildPageMeta, canonicalUrl } from '../../src/lib/seo.js';

it('normalizes canonical paths', () => {
  expect(canonicalUrl('/features/financial-control')).toBe('https://managestate.app/features/financial-control/');
});

it('returns complete English metadata', () => {
  const meta = buildPageMeta({
    title: 'Property Management App for Small Landlords | ManageState',
    description: 'Track rental finances, documents, and portfolio performance from one iPhone app.',
    path: '/'
  });
  expect(meta.lang).toBe('en');
  expect(meta.canonical).toBe('https://managestate.app/');
  expect(meta.og.type).toBe('website');
});
```

- [ ] **Step 2: Run the tests and verify failure**

Run: `cd landing-page && npm test -- tests/seo/seo.test.mjs`
Expected: FAIL because `src/lib/seo.js` does not exist.

- [ ] **Step 3: Implement metadata generation and `SeoHead`**

`canonicalUrl` must remove query strings, enforce a leading and trailing slash, and resolve against the configured site URL. `buildPageMeta` must reject an empty title/description, default to English, use `/social/managestate-og.png`, and return canonical, robots, Open Graph, and Twitter values. `SeoHead.astro` must render canonical, robots, description, Open Graph, Twitter card, alternate language links, and each JSON-LD object passed in `schemas`.

- [ ] **Step 4: Create `BaseLayout.astro` and global styles**

The layout must render `<html lang>`, `SeoHead`, skip navigation, header/main/footer slots, and the existing dark Tailwind base styles. Move active rules from `src/index.css`; do not carry unused Vite demo styles from `src/App.css`.

Extend `site.json` with `privacyUrl: "https://managestate.app/privacy/"` and `termsUrl: "https://managestate.app/terms/"`. The validator must reject missing, non-HTTPS, or off-domain legal URLs.

- [ ] **Step 5: Run tests and build the empty shell**

Run: `cd landing-page && npm test -- tests/seo/seo.test.mjs && npm run build`
Expected: metadata tests PASS. The build may report no page routes until Task 3, but configuration must load without syntax errors.

- [ ] **Step 6: Commit the SEO layout**

```bash
git add landing-page/src/lib/seo.js landing-page/src/layouts/BaseLayout.astro landing-page/src/components/SeoHead.astro landing-page/src/styles/global.css landing-page/src/data/site.json landing-page/scripts/seo/validate-baseline-data.mjs landing-page/tests/seo/seo.test.mjs landing-page/tests/seo/validate-baseline-data.test.mjs
git commit -m "feat(landing): add canonical SEO layout"
```

### Task 3: Rebuild the homepage as static Astro sections

**Files:**
- Create: `landing-page/src/pages/index.astro`
- Create: `landing-page/src/components/site/Header.astro`
- Create: `landing-page/src/components/site/Footer.astro`
- Create: `landing-page/src/components/home/Hero.astro`
- Create: `landing-page/src/components/home/Evidence.astro`
- Create: `landing-page/src/components/home/Features.astro`
- Create: `landing-page/src/components/home/Faq.astro`
- Create: `landing-page/src/components/home/FinalCta.astro`
- Create: `landing-page/tests/pages/homepage.test.mjs`
- Delete: `landing-page/src/App.jsx`
- Delete: `landing-page/src/App.css`

**Interfaces:**
- Consumes: verified evidence JSON, static hero asset, shared layout, and App Store CTA component introduced in Task 4.
- Produces: statically rendered `/` with one H1 and crawlable section/navigation links.

- [ ] **Step 1: Write a failing built-homepage contract test**

Create a test that reads `dist/index.html` after a build and asserts: title is not `landing-page`; one H1 contains `property` or `landlord`; no `avatar.vercel.sh`; no `Join thousands`; no `href="#"`; hero image has descriptive alt text; and the Features and FAQ anchors exist.

- [ ] **Step 2: Run build/test and verify failure**

Run: `cd landing-page && npm run build && npm test -- tests/pages/homepage.test.mjs`
Expected: FAIL because `/` does not exist.

- [ ] **Step 3: Implement semantic site chrome and homepage sections**

Use this homepage metadata:

```js
{
  title: 'Property Management App for Small Landlords | ManageState',
  description: 'Track rental income, expenses, documents, and property performance in one straightforward iPhone app for independent landlords.',
  path: '/'
}
```

Use one H1: `Rental property management, without spreadsheet chaos.` Preserve the current hero image as `/hero-tilted.png` with alt text `ManageState dashboard showing rental property finances and portfolio performance`. Convert navigation and sections to semantic Astro markup. Render Evidence only when validated evidence arrays are non-empty. Replace “Start for Free,” “Start Now,” and “View Demo” dead buttons with working App Store links or meaningful section links.

- [ ] **Step 4: Add factual visible FAQs**

Include visible answers for who ManageState serves, whether a card is needed only if verified by product evidence, supported financial/document workflows, and data/privacy links. Do not add FAQ schema until the structured-data task confirms policy eligibility.

- [ ] **Step 5: Build and run the homepage contract**

Run: `cd landing-page && npm run build && npm test -- tests/pages/homepage.test.mjs`
Expected: PASS; `dist/index.html` contains substantive static copy.

- [ ] **Step 6: Commit the static homepage**

```bash
git add landing-page/src/pages/index.astro landing-page/src/components/site landing-page/src/components/home landing-page/tests/pages/homepage.test.mjs
git rm landing-page/src/App.jsx landing-page/src/App.css
git commit -m "feat(landing): render homepage as static Astro HTML"
```

### Task 4: Add measurable App Store links and failure-tolerant Plausible events

**Files:**
- Create: `landing-page/src/lib/app-store.js`
- Create: `landing-page/src/components/AppStoreLink.astro`
- Create: `landing-page/src/scripts/analytics.js`
- Create: `landing-page/tests/analytics/app-store.test.mjs`
- Modify: homepage/site components from Task 3

**Interfaces:**
- Consumes: campaign name, placement, cluster, language, optional `PUBLIC_APPLE_PROVIDER_TOKEN`, and `PUBLIC_PLAUSIBLE_DOMAIN`.
- Produces: `buildAppStoreUrl(campaign, providerToken)` and `app_store_click` with `{ page_path, content_cluster, cta_placement, language, campaign }`.

- [ ] **Step 1: Write failing App Store URL tests**

```js
import { expect, it } from 'vitest';
import { buildAppStoreUrl } from '../../src/lib/app-store.js';

it('builds a working unattributed fallback', () => {
  expect(buildAppStoreUrl('website-home', '')).toBe('https://apps.apple.com/app/managestate/id6751497970');
});

it('adds Apple campaign attribution when provider token exists', () => {
  expect(buildAppStoreUrl('website-home', '123456')).toContain('pt=123456&ct=website-home&mt=8');
});
```

- [ ] **Step 2: Implement URL validation and the Astro CTA**

Reject campaign names outside `/^[a-z0-9-]+$/`. Render a normal external anchor even when analytics configuration is absent. Add `data-app-store-click`, `data-page-path`, `data-content-cluster`, `data-cta-placement`, `data-language`, and `data-campaign` attributes.

- [ ] **Step 3: Implement analytics without intercepting navigation**

Load Plausible only when `PUBLIC_PLAUSIBLE_DOMAIN` equals `managestate.app`. Use a document click listener that calls `window.plausible?.('app_store_click', { props })`; do not call `preventDefault`, await a network request, or throw when Plausible is unavailable.

- [ ] **Step 4: Add CTAs to all approved placements**

Use placements `nav`, `hero`, `evidence`, and `final`. Use campaign `website-home` and content cluster `home`. Ensure all CTA text is `Download ManageState for iPhone` or a shorter accessible equivalent with an explicit accessible label.

- [ ] **Step 5: Run tests and manually verify failure behavior**

Run: `cd landing-page && npm test -- tests/analytics/app-store.test.mjs && npm run build`
Expected: PASS. In preview with Plausible blocked, clicking every CTA still opens the App Store URL.

- [ ] **Step 6: Commit conversion tracking**

```bash
git add landing-page/src/lib/app-store.js landing-page/src/components/AppStoreLink.astro landing-page/src/scripts/analytics.js landing-page/tests/analytics/app-store.test.mjs landing-page/src/pages/index.astro landing-page/src/components
git commit -m "feat(landing): add measurable App Store conversion links"
```

### Task 5: Add structured data, robots, sitemap, and build validation

**Files:**
- Create: `landing-page/src/lib/schema.js`
- Create: `landing-page/public/robots.txt`
- Create: `landing-page/public/favicon.svg`
- Create: `landing-page/public/social/managestate-og.png`
- Create: `landing-page/scripts/seo/validate-dist.mjs`
- Create: `landing-page/tests/seo/schema.test.mjs`
- Create: `landing-page/tests/seo/validate-dist.test.mjs`
- Create: `landing-page/lighthouserc.cjs`
- Modify: `landing-page/.gitignore`
- Modify: `landing-page/src/pages/index.astro`
- Modify: `landing-page/src/layouts/BaseLayout.astro`
- Delete: `landing-page/public/vite.svg`
- Delete: `landing-page/src/assets/react.svg`

**Interfaces:**
- Consumes: visible homepage content and built `dist/` files.
- Produces: Organization and SoftwareApplication JSON-LD plus a release-blocking static-site validator.

- [ ] **Step 1: Write failing schema and dist tests**

Assert that SoftwareApplication schema contains `@type`, app name, operating system `iOS`, category, and verified App Store URL, but contains no fabricated aggregate rating. Assert that Organization schema contains only verified name and URL. Dist validation must reject missing title, description, canonical, H1, image alt, sitemap membership, or dead placeholder links.

- [ ] **Step 2: Implement schema builders**

Export `buildOrganizationSchema()` and `buildSoftwareApplicationSchema()`. Add aggregate ratings only if verified review data contains enough source values to calculate an accurate count and average; otherwise omit the property entirely.

- [ ] **Step 3: Add crawl assets**

`robots.txt` must allow crawling and reference `https://managestate.app/sitemap-index.xml`. Generate a branded SVG favicon and a 1200×630 social image from approved brand assets. Remove Vite/React logos.

- [ ] **Step 4: Implement `validate-dist.mjs`**

Walk built HTML files; enforce unique titles/descriptions/canonicals/H1s, exactly one canonical, no `href="#"`, no Vite branding, and canonical URLs matching file paths. Parse `sitemap-index.xml`/child sitemap output and ensure every canonical indexable page appears once. Print file-specific errors and exit non-zero.

- [ ] **Step 5: Add Core Web Vitals laboratory budgets and run verification**

Create `lighthouserc.cjs` with `staticDistDir: './dist'`, one local run, filesystem-only reports under ignored `.lighthouseci/`, and release-blocking maximums of 2,500 ms Largest Contentful Paint, 0.10 Cumulative Layout Shift, and 200 ms Total Blocking Time. Add `check:lighthouse: "lhci autorun --config=lighthouserc.cjs"` and run it after `check:dist` in `verify`; field INP is monitored later in Search Console because Lighthouse cannot reproduce field interaction data.

Run: `cd landing-page && npm run verify`
Expected: lint, tests, evidence validation, Astro build, dist validation, and Lighthouse Core Web Vitals proxy budgets all PASS.

- [ ] **Step 6: Commit technical SEO assets**

```bash
git add landing-page/src/lib/schema.js landing-page/src/pages/index.astro landing-page/src/layouts/BaseLayout.astro landing-page/public/robots.txt landing-page/public/favicon.svg landing-page/public/social/managestate-og.png landing-page/scripts/seo/validate-dist.mjs landing-page/tests/seo landing-page/lighthouserc.cjs landing-page/.gitignore landing-page/package.json landing-page/package-lock.json
git rm landing-page/public/vite.svg landing-page/src/assets/react.svg
git commit -m "feat(landing): enforce technical SEO release gates"
```

### Task 6: Add legal links and landing-site CI

**Files:**
- Create: `landing-page/src/pages/privacy.astro`
- Create: `landing-page/src/pages/terms.astro`
- Modify: `landing-page/src/components/site/Footer.astro`
- Modify: `.github/workflows/verify.yml`
- Create: `landing-page/README.md`

**Interfaces:**
- Consumes: the approved privacy and terms source text referenced by the mobile app configuration.
- Produces: crawlable local `/privacy/` and `/terms/` destinations plus an independent `verify-landing` CI job.

- [ ] **Step 1: Add legal-route tests to the dist validator**

Require `/privacy/` and `/terms/` to return built HTML, use self-canonical URLs, and be linked from the footer. The privacy destination must disclose Plausible Analytics and the `app_store_click` event before analytics is enabled.

- [ ] **Step 2: Implement local legal destinations without inventing legal promises**

Migrate the owner-approved privacy and terms text referenced by the mobile app configuration into `/privacy/` and `/terms/`. Add the factual Plausible and outbound-event disclosure to privacy copy, preserve the approval date, and route footer links to the local pages. If approved source policies cannot be obtained, stop this task and keep analytics disabled; do not draft warranty, retention, encryption, or compliance language.

- [ ] **Step 3: Add the CI job**

Add `verify-landing` with Node `22.13.0`, `cache-dependency-path: landing-page/package-lock.json`, `working-directory: landing-page`, `npm ci`, and `npm run verify`. Keep the existing mobile `verify` job unchanged.

- [ ] **Step 4: Document local and deployment commands**

Replace the Vite README with exact Astro commands, required public environment variables, static `dist/` output, campaign naming, and the Phase 1 verification command.

- [ ] **Step 5: Run both local verification surfaces**

Run:

```bash
cd landing-page && npm ci && npm run verify
cd .. && npm test -- --runInBand
```

Expected: landing verification PASS; existing mobile tests remain PASS.

- [ ] **Step 6: Commit CI and operations documentation**

```bash
git add .github/workflows/verify.yml landing-page/README.md landing-page/src/components/site/Footer.astro landing-page/src/pages/privacy.astro landing-page/src/pages/terms.astro landing-page/scripts/seo/validate-dist.mjs landing-page/tests
git commit -m "ci(landing): verify static SEO site independently"
```

## Phase 1 Exit Gate

Run `cd landing-page && npm ci && npm run verify && npm run preview`. Confirm `/`, the legal destinations, `robots.txt`, and `sitemap-index.xml` load; inspect source HTML with JavaScript disabled; click every App Store CTA with Plausible blocked; and validate the live deployment in Search Console URL Inspection. Proceed only when static metadata, structured data, sitemap membership, legal disclosure, CI, and working App Store navigation are verified.
