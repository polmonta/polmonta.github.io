# SEO Phase 0: Baseline and Evidence Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Establish verified SEO, analytics, App Store, and evidence inputs before changing or scaling the marketing site.

**Architecture:** Keep operational SEO inputs in versioned JSON with dependency-free Node validators; keep raw exports and credentials outside Git. Google Search Console, Plausible, and App Store Connect remain systems of record, while concise baselines and verified public evidence are committed for later site and content work.

**Tech Stack:** Node.js 22.13.0, Node test runner, Google Search Console, Plausible Analytics, App Store Connect, Apple iTunes Lookup/RSS APIs, JSON and Markdown.

## Global Constraints

- Source of truth: `docs/superpowers/specs/2026-08-05-managestate-seo-growth-design.md`.
- Primary audience: self-managing landlords with one to five properties; growing investors are secondary.
- English launches first; Spanish follows proven English pages; Catalan follows Spanish.
- Primary conversion is an Apple App Store download for App Store ID `6751497970` and bundle ID `com.managestate.app`.
- Store only verified App Store reviews, customer testimonials, screenshots, and product claims.
- Do not commit credentials, private analytics exports, customer property data, or personally identifiable customer data.
- Do not publish generated testimonial identities, `avatar.vercel.sh` avatars, or the “thousands of property owners” claim without evidence.
- Existing untracked project files must not be staged accidentally; every commit command names exact files.

---

### Task 1: Add a validated site and evidence data contract

**Files:**
- Create: `landing-page/src/data/site.json`
- Create: `landing-page/src/data/evidence/app-store-reviews.json`
- Create: `landing-page/src/data/evidence/customer-testimonials.json`
- Create: `landing-page/src/data/evidence/product-claims.json`
- Create: `landing-page/src/data/evidence/screenshots.json`
- Create: `landing-page/scripts/seo/validate-baseline-data.mjs`
- Create: `landing-page/tests/seo/validate-baseline-data.test.mjs`
- Modify: `landing-page/package.json`

**Interfaces:**
- Consumes: App Store ID `6751497970`, bundle ID `com.managestate.app`, and canonical site URL `https://managestate.app`.
- Produces: `validateBaselineData({ site, reviews, testimonials, claims, screenshots }): string[]`; later phases may render evidence only when this function returns an empty array.

- [ ] **Step 1: Write the failing contract test**

```js
// landing-page/tests/seo/validate-baseline-data.test.mjs
import test from 'node:test';
import assert from 'node:assert/strict';
import { validateBaselineData } from '../../scripts/seo/validate-baseline-data.mjs';

const site = {
  siteUrl: 'https://managestate.app',
  appStoreId: '6751497970',
  appStoreBaseUrl: 'https://apps.apple.com/app/managestate/id6751497970',
  bundleId: 'com.managestate.app',
  primaryLanguage: 'en',
  supportedLanguages: ['en', 'es', 'ca'],
  plausibleDomain: 'managestate.app'
};

test('accepts the approved site contract and empty evidence lists', () => {
  assert.deepEqual(validateBaselineData({ site, reviews: [], testimonials: [], claims: [], screenshots: [] }), []);
});

test('rejects unverified evidence and unsupported claims', () => {
  const errors = validateBaselineData({
    site,
    reviews: [{ id: 'r1', quote: 'Great', verified: false, sourceUrl: '' }],
    testimonials: [],
    claims: [{ id: 'c1', text: 'Trusted by thousands', status: 'unsupported' }],
    screenshots: []
  });
  assert.match(errors.join('\n'), /review r1 must be verified/);
  assert.match(errors.join('\n'), /claim c1 must have status verified/);
});
```

- [ ] **Step 2: Run the test and verify it fails**

Run: `node --test landing-page/tests/seo/validate-baseline-data.test.mjs`
Expected: FAIL with `ERR_MODULE_NOT_FOUND` for `validate-baseline-data.mjs`.

- [ ] **Step 3: Create the data files and validator**

```json
// landing-page/src/data/site.json
{
  "siteUrl": "https://managestate.app",
  "appStoreId": "6751497970",
  "appStoreBaseUrl": "https://apps.apple.com/app/managestate/id6751497970",
  "bundleId": "com.managestate.app",
  "primaryLanguage": "en",
  "supportedLanguages": ["en", "es", "ca"],
  "plausibleDomain": "managestate.app"
}
```

Create each evidence JSON file as `[]`. Implement the validator with these rules: exact site/app identifiers; unique evidence IDs; non-empty quotes; `verified === true`; non-empty `sourceUrl` for reviews; `sourceRecord` for testimonials; `status === "verified"` plus `source` for claims; and, for screenshots, a repository-relative public asset path, descriptive alt text, captured app version, approval date, and `verified: true`. Export `validateBaselineData` and add a CLI branch that reads all evidence JSON files, prints every error, and exits non-zero when errors exist.

- [ ] **Step 4: Add and run the package script**

Add to `landing-page/package.json`:

```json
"test:baseline": "node --test tests/seo/validate-baseline-data.test.mjs",
"check:baseline": "node scripts/seo/validate-baseline-data.mjs"
```

Run: `cd landing-page && npm run test:baseline && npm run check:baseline`
Expected: both commands PASS; the validator prints `Baseline data valid`.

- [ ] **Step 5: Commit the data contract**

```bash
git add landing-page/package.json landing-page/src/data/site.json landing-page/src/data/evidence landing-page/scripts/seo/validate-baseline-data.mjs landing-page/tests/seo/validate-baseline-data.test.mjs
git commit -m "feat(seo): define verified baseline data contract"
```

### Task 2: Import verifiable App Store metadata and reviews

**Files:**
- Create: `landing-page/scripts/seo/import-app-store-evidence.mjs`
- Create: `landing-page/tests/seo/import-app-store-evidence.test.mjs`
- Create: `landing-page/tests/fixtures/apple-lookup.json`
- Create: `landing-page/tests/fixtures/apple-reviews.json`
- Modify: `landing-page/package.json`
- Modify: `landing-page/src/data/evidence/app-store-reviews.json`

**Interfaces:**
- Consumes: Apple Lookup endpoint for bundle ID `com.managestate.app` and Apple customer-review RSS for app ID `6751497970`.
- Produces: `parseLookup(payload)` and `parseReviews(payload)` plus normalized verified review records `{ id, quote, author, rating, locale, sourceUrl, verified }`.

- [ ] **Step 1: Save deterministic fixtures and write parser tests**

Use a single lookup result with `trackId: 6751497970`, `trackName: "ManageState"`, and a single review entry containing an ID, author, rating, title, content, and link. Assert that a mismatched track ID throws and that a valid review normalizes to `verified: true` with a public Apple source URL.

```js
import test from 'node:test';
import assert from 'node:assert/strict';
import { parseLookup, parseReviews } from '../../scripts/seo/import-app-store-evidence.mjs';
import lookup from '../fixtures/apple-lookup.json' with { type: 'json' };
import reviews from '../fixtures/apple-reviews.json' with { type: 'json' };

test('accepts only the ManageState listing', () => {
  assert.equal(parseLookup(lookup).trackId, 6751497970);
});

test('normalizes Apple reviews as verified evidence', () => {
  const [review] = parseReviews(reviews, 'us');
  assert.equal(review.verified, true);
  assert.match(review.sourceUrl, /^https:\/\/apps\.apple\.com\//);
});
```

- [ ] **Step 2: Run the parser tests and verify failure**

Run: `node --test landing-page/tests/seo/import-app-store-evidence.test.mjs`
Expected: FAIL because the importer does not exist.

- [ ] **Step 3: Implement the importer**

Use native `fetch`, reject non-200 responses, validate the app ID and bundle ID, deduplicate reviews by Apple entry ID, and write sorted JSON. Fetch US and Spain storefront reviews because English and Spanish are the first two rollout languages. Do not infer customer counts or rewrite review wording.

- [ ] **Step 4: Run the importer and validators**

Run: `cd landing-page && node scripts/seo/import-app-store-evidence.mjs && npm run test:baseline && npm run check:baseline`
Expected: PASS. If Apple returns no reviews, `app-store-reviews.json` remains a valid empty array and the importer prints `0 verified reviews imported`.

- [ ] **Step 5: Commit imported public evidence**

```bash
git add landing-page/package.json landing-page/scripts/seo/import-app-store-evidence.mjs landing-page/tests/seo/import-app-store-evidence.test.mjs landing-page/tests/fixtures/apple-lookup.json landing-page/tests/fixtures/apple-reviews.json landing-page/src/data/evidence/app-store-reviews.json
git commit -m "feat(seo): import verified App Store evidence"
```

### Task 3: Establish measurement accounts and record the baseline

**Files:**
- Create: `docs/seo/measurement-setup.md`
- Create: `docs/seo/baselines/2026-08-05-baseline.md`
- Create: `landing-page/seo-ops/keywords/search-console-questions.json`
- Create: `landing-page/seo-ops/private/.gitignore`
- Create: `landing-page/seo-ops/README.md`

**Interfaces:**
- Consumes: Search Console property access, Plausible site access, App Store Connect campaign access, and the current live site.
- Produces: an auditable baseline containing observed values and account status without credentials or raw customer data.

- [ ] **Step 1: Create the private-export boundary**

`landing-page/seo-ops/private/.gitignore` must contain:

```gitignore
*
!.gitignore
```

Document that Search Console CSV files, Plausible exports, App Store Connect exports, provider tokens, and screenshots containing account details stay in this directory and are never committed.

- [ ] **Step 2: Verify or create the Search Console domain property**

Use the domain property `managestate.app`. Verify DNS ownership, inspect indexing, submit `https://managestate.app/sitemap-index.xml` after Phase 1, and export the last available 90 days of Pages and Queries into `landing-page/seo-ops/private/`. Filter question queries with `^(who|what|where|when|why|how|which|can|do|does|is|are|should|will)\b` and store only aggregate `{ query, clicks, impressions, position, sourceWindow }` records in `search-console-questions.json`. If no historical data exists, commit an empty array and record zero available days rather than estimating values.

- [ ] **Step 3: Create the Plausible site and App Store campaigns**

Create the Plausible domain `managestate.app`. In App Store Connect, create campaign links for `website-home`, `website-features`, `website-audiences`, `website-comparisons`, `website-guides`, `website-tools`, `medium`, `substack`, and `youtube`. Record public campaign URLs in the baseline; keep any account/provider token in deployment secrets.

- [ ] **Step 4: Write the baseline using observed values**

The committed baseline must state: Search Console ownership status; date range available; total indexed and excluded URLs; impressions, clicks, CTR, and top non-branded queries; current live title and indexability; Plausible setup status; App Store listing URL; campaign names created; count of verified reviews/testimonials/claims; and known data gaps. Use actual exported values, including zero when zero is observed.

- [ ] **Step 5: Review for sensitive data and commit**

Run: `git diff --check -- docs/seo landing-page/seo-ops`
Expected: no whitespace errors and no credentials in the diff.

```bash
git add docs/seo/measurement-setup.md docs/seo/baselines/2026-08-05-baseline.md landing-page/seo-ops/keywords/search-console-questions.json landing-page/seo-ops/README.md landing-page/seo-ops/private/.gitignore
git commit -m "docs(seo): record acquisition measurement baseline"
```

### Task 4: Add verified customer evidence without inventing proof

**Files:**
- Modify: `landing-page/src/data/evidence/customer-testimonials.json`
- Modify: `landing-page/src/data/evidence/product-claims.json`
- Modify: `landing-page/src/data/evidence/screenshots.json`
- Create: `docs/seo/evidence-register.md`

**Interfaces:**
- Consumes: the few real customer testimonials supplied by the owner and product claims confirmed against the shipping app.
- Produces: render-safe verified evidence; empty arrays remain the correct result when provenance is unavailable.

- [ ] **Step 1: Create the evidence register format**

For each accepted testimonial, record a stable ID, exact approved quote, display name or approved initials, source-record location, consent status, approval date, allowed languages, and `verified: true`. For each product claim, record exact wording, verification source, verification date, and `status: "verified"`. For each screenshot, record its public asset path, descriptive alt text, captured app version, approval date, and the product claims visibly supported by the image.

- [ ] **Step 2: Add only records with provenance**

Do not migrate the four names or avatars currently embedded in `landing-page/src/App.jsx` unless matching source records and publication consent exist. Leave the JSON arrays empty for any category with no acceptable evidence.

- [ ] **Step 3: Run the validator**

Run: `cd landing-page && npm run check:baseline`
Expected: PASS. Any record missing source or consent fails with a record-specific error.

- [ ] **Step 4: Cross-check shipping product claims**

Verify financial tracking, document storage, ROI calculations, tax export behavior, plan/card wording, encryption language, and supported devices against the current app and App Store listing. Remove wording that cannot be confirmed; do not soften an unsupported claim into another unsupported claim.

- [ ] **Step 5: Commit the evidence inventory**

```bash
git add landing-page/src/data/evidence/customer-testimonials.json landing-page/src/data/evidence/product-claims.json landing-page/src/data/evidence/screenshots.json docs/seo/evidence-register.md
git commit -m "docs(seo): inventory verified marketing evidence"
```

## Phase 0 Exit Gate

Run:

```bash
cd landing-page
npm run test:baseline
npm run check:baseline
cd ..
git status --short
```

Proceed to Phase 1 only when the tests pass, Search Console ownership has a recorded status, Plausible is configured, App Store campaigns exist, the baseline contains observed values, and every committed review, testimonial, claim, and screenshot passes provenance validation. Residual account-access blockers must be listed in the baseline rather than concealed.
