# SEO Phase 3: External Authority Distribution Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Establish a controlled, measurable external publication workflow that amplifies validated ManageState content without duplicate spam or automated account posting.

**Architecture:** A versioned publication ledger is the operational source of truth; validators enforce unique topics, valid state transitions, deep links, and public-URL verification. Platform-specific content packs are reviewed in Git, then published manually to Medium, Substack, and YouTube at one to two items per week.

**Tech Stack:** Node.js 22.13.0, Node/Vitest tests, JSON, Markdown, Plausible, App Store Connect campaigns, Medium, Substack, YouTube.

## Global Constraints

- Phase 2 exit gate must pass and the source page must be live before an external adaptation is queued.
- `managestate.app` remains the canonical source and long-term SEO asset.
- Initial cadence is one to two external publications per week.
- No browser automation, account networks, direct auto-posting, automated community promotion, or copied article blasts.
- Every external item must stand alone, be original or meaningfully adapted, and deep-link to the most relevant ManageState page.
- Medium uses a canonical source link for true republications where supported.
- GitHub is excluded until a genuinely useful public asset exists.
- A publication is `published` only after its public URL resolves and is manually inspected.
- Failed publication attempts return to a retryable state and do not consume the topic.

---

### Task 1: Create the publication ledger and state machine

**Files:**
- Create: `landing-page/seo-ops/publications.json`
- Create: `landing-page/seo-ops/publication-schema.json`
- Create: `landing-page/scripts/seo/publication-ledger.mjs`
- Create: `landing-page/tests/seo/publication-ledger.test.mjs`
- Modify: `landing-page/package.json`

**Interfaces:**
- Consumes: publication records `{ id, topicId, platform, sourcePath, destinationUrl, campaign, status, attempts, publicUrl, publishedAt, lastError }`.
- Produces: `validateLedger(records): string[]` and `transitionPublication(record, nextStatus, detail)`.

- [ ] **Step 1: Write failing transition tests**

```js
import { expect, it } from 'vitest';
import { transitionPublication, validateLedger } from '../../scripts/seo/publication-ledger.mjs';

const queued = {
  id: 'medium-spreadsheets-001', topicId: 'landlord-app-vs-spreadsheets',
  platform: 'medium', sourcePath: '/compare/landlord-app-vs-spreadsheets/',
  destinationUrl: 'https://managestate.app/compare/landlord-app-vs-spreadsheets/',
  campaign: 'medium', status: 'queued', attempts: 0, publicUrl: null,
  publishedAt: null, lastError: null
};

it('requires public verification before published', () => {
  expect(() => transitionPublication(queued, 'published', {})).toThrow(/publicUrl/);
});

it('returns failed work to retry without burning the topic', () => {
  const failed = transitionPublication(queued, 'failed', { error: 'login expired' });
  const retry = transitionPublication(failed, 'queued', {});
  expect(retry.attempts).toBe(1);
  expect(retry.lastError).toBe('login expired');
});
```

- [ ] **Step 2: Implement explicit states and invariants**

Allowed states: `queued`, `drafting`, `review`, `ready`, `published`, `failed`, `retired`. Enforce unique `id`; unique `platform + topicId` for non-retired records; source/destination on `managestate.app`; platform in `medium|substack|youtube`; campaign matching platform; and `publicUrl` plus ISO `publishedAt` for published records.

- [ ] **Step 3: Add ledger CLI commands**

Support `validate`, `transition <id> <state>`, and `list <state>`. Every write must use a temporary file plus atomic rename. Do not store credentials or platform cookies.

- [ ] **Step 4: Add package scripts and run tests**

```json
"check:publications": "node scripts/seo/publication-ledger.mjs validate"
```

Run: `cd landing-page && npm test -- tests/seo/publication-ledger.test.mjs && npm run check:publications`
Expected: PASS with an initially empty ledger.

- [ ] **Step 5: Commit the ledger**

```bash
git add landing-page/seo-ops/publications.json landing-page/seo-ops/publication-schema.json landing-page/scripts/seo/publication-ledger.mjs landing-page/tests/seo/publication-ledger.test.mjs landing-page/package.json
git commit -m "feat(seo): add controlled external publication ledger"
```

### Task 2: Build deterministic deep links and publication verification

**Files:**
- Create: `landing-page/scripts/seo/build-external-link.mjs`
- Create: `landing-page/scripts/seo/verify-publication.mjs`
- Create: `landing-page/tests/seo/external-links.test.mjs`
- Create: `landing-page/tests/fixtures/publication-page.html`

**Interfaces:**
- Consumes: source path, platform campaign, public URL, and expected destination.
- Produces: external destination links and verification result `{ reachable, public, destinationFound, canonicalMatches }`.

- [ ] **Step 1: Write failing link tests**

Assert that the Medium comparison destination is `https://managestate.app/compare/landlord-app-vs-spreadsheets/?ref=medium`; the function rejects off-domain destinations and unknown campaigns; and verification rejects editor, draft, login, preview, or non-200 URLs.

- [ ] **Step 2: Implement external destination URLs**

Use `ref=medium|substack|youtube` only for web analytics attribution; App Store campaign links remain inside the destination page. Preserve canonical URL generation without the `ref` query.

- [ ] **Step 3: Implement public-page verification**

Use native fetch with redirect following, a 10-second timeout, and a browser-like user agent. Require final status 200, no editor/draft/login path markers, and expected ManageState destination in returned HTML when the platform exposes body/description HTML. For YouTube, require public status and perform destination-link confirmation manually if page HTML does not expose the description.

- [ ] **Step 4: Test without calling live platforms**

Run: `cd landing-page && npm test -- tests/seo/external-links.test.mjs`
Expected: PASS against fixtures; network is mocked.

- [ ] **Step 5: Commit link and verification tooling**

```bash
git add landing-page/scripts/seo/build-external-link.mjs landing-page/scripts/seo/verify-publication.mjs landing-page/tests/seo/external-links.test.mjs landing-page/tests/fixtures/publication-page.html
git commit -m "feat(seo): verify external publication destinations"
```

### Task 3: Create three platform-specific pilot content packs

**Files:**
- Create: `landing-page/seo-ops/external/medium/landlord-app-vs-spreadsheets.md`
- Create: `landing-page/seo-ops/external/substack/monthly-rental-finance-routine.md`
- Create: `landing-page/seo-ops/external/youtube/roi-calculator-walkthrough.md`
- Create: `landing-page/tests/seo/external-content.test.mjs`
- Modify: `landing-page/seo-ops/publications.json`

**Interfaces:**
- Consumes: three live source pages and only claims/evidence already approved on those pages.
- Produces: one ready-to-review adaptation per initial platform, each with a distinct angle and deep link.

- [ ] **Step 1: Write a failing adaptation-quality test**

Assert every pack declares `topicId`, `platform`, `sourcePath`, `destinationUrl`, `primaryQuestion`, `summary`, and `reviewStatus`; contains the destination link; has no `trusted by thousands`; and does not copy more than 30% of normalized sentences from its source-page Markdown.

- [ ] **Step 2: Write the Medium adaptation**

Title: `When a Landlord App Beats a Spreadsheet—and When It Doesn’t`. Structure: standalone answer; signs a spreadsheet is enough; signs it is becoming fragile; mobile/document/calculation trade-offs; migration checklist; transparent ManageState mention; deep link to the spreadsheet comparison. If copied verbatim, configure Medium canonical to the source; otherwise keep it an original adaptation.

- [ ] **Step 3: Write the Substack adaptation**

Title: `A 20-Minute Monthly Rental Finance Routine`. Structure: monthly checklist; income reconciliation; expense/document pass; property-level review; questions for an accountant; short ManageState workflow; deep link to the rental income/expense guide. Do not frame organizational categories as tax advice.

- [ ] **Step 4: Write the YouTube production pack**

Title: `How to Calculate Rental Property ROI Without Fooling Yourself`. Include a 5–7 minute script, shot list, calculator inputs, worked example using the tested values from `roi.test.mjs`, disclaimer, chapters, thumbnail text, description, and deep link to the ROI calculator. Do not claim the calculator predicts future returns.

- [ ] **Step 5: Add queued ledger records and test**

Run: `cd landing-page && npm test -- tests/seo/external-content.test.mjs && npm run check:publications`
Expected: three unique queued records and all content checks PASS.

- [ ] **Step 6: Commit the pilot packs**

```bash
git add landing-page/seo-ops/external landing-page/seo-ops/publications.json landing-page/tests/seo/external-content.test.mjs
git commit -m "docs(seo): prepare external authority pilot content"
```

### Task 4: Publish manually and record verified public URLs

**Files:**
- Modify: `landing-page/seo-ops/publications.json`
- Create: `docs/seo/releases/phase-3-publication-log.md`

**Interfaces:**
- Consumes: reviewed content packs and authenticated human-controlled platform accounts.
- Produces: verified public URLs and publication dates; no credentials enter the repository.

- [ ] **Step 1: Move one record at a time through review**

Use CLI transitions `queued → drafting → review → ready`. A human compares claims, links, title, images, and platform preview to the committed pack before publication.

- [ ] **Step 2: Publish at the approved cadence**

Publish no more than two items in any seven-day period. Use native platform scheduling only when it still requires an approved final draft. Do not use browser automation.

- [ ] **Step 3: Verify each public URL**

Run: `node landing-page/scripts/seo/verify-publication.mjs <record-id> <public-url>`
Expected: status 200, public final URL, and confirmed destination when inspectable. Manually confirm canonical configuration, visible destination link, thumbnail/image, and transcript/description.

- [ ] **Step 4: Mark success or retryable failure**

On success, transition to `published` with exact URL/date. On login, moderation, draft, or link failure, transition to `failed`, record the factual reason, fix it, and return to `queued`; do not create a new topic ID.

- [ ] **Step 5: Commit publication state separately**

```bash
git add landing-page/seo-ops/publications.json docs/seo/releases/phase-3-publication-log.md
git commit -m "docs(seo): record verified external publications"
```

### Task 5: Measure the pilot and choose the next topics

**Files:**
- Create: `docs/seo/reviews/phase-3-30-day-review.md`
- Create: `landing-page/seo-ops/external/topic-queue.json`
- Create: `landing-page/scripts/seo/validate-topic-queue.mjs`
- Create: `landing-page/tests/seo/topic-queue.test.mjs`

**Interfaces:**
- Consumes: publication ledger, Plausible referrals, Search Console links/query data, and App Store campaign outcomes.
- Produces: a scored queue whose topics always map to live ManageState destinations.

- [ ] **Step 1: Define the queue scoring contract**

Score each candidate from 0–5 for commercial intent, audience fit, source-page evidence, source-page search signal, external-format fit, and editorial effort (reverse-scored). Store component scores and total; never store invented volume/CPC values.

- [ ] **Step 2: Write validator tests**

Reject duplicate topic/platform pairs, missing live source paths, unknown platforms, totals that do not equal component sums, and a queue exceeding the one-to-two-per-week capacity for the next four weeks.

- [ ] **Step 3: Record actual 30-day outcomes**

For each publication record public/indexed status, referral visits, engaged visits, App Store clicks, attributed product-page views/downloads when available, and any qualitative discovery. Use zero when observed and `not available` only when the system cannot provide the metric.

- [ ] **Step 4: Build the next four-week queue**

Select at most eight records, prioritizing formats that showed qualified discovery or conversion. Retire a format only with a written reason; do not scale from impressions alone.

- [ ] **Step 5: Verify and commit**

Run: `cd landing-page && npm test -- tests/seo/topic-queue.test.mjs && node scripts/seo/validate-topic-queue.mjs && npm run check:publications`
Expected: PASS.

```bash
git add docs/seo/reviews/phase-3-30-day-review.md landing-page/seo-ops/external/topic-queue.json landing-page/scripts/seo/validate-topic-queue.mjs landing-page/tests/seo/topic-queue.test.mjs
git commit -m "docs(seo): review external distribution pilot"
```

## Phase 3 Exit Gate

Complete at least one verified publication on each selected platform or record a platform-specific blocker. Confirm cadence compliance, unique content, working deep links, public URL verification, ledger consistency, and a 30-day evidence review. Do not proceed to automation merely because publishing succeeded; Phase 5 has a separate eligibility gate.
