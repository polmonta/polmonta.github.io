# SEO Phase 4: Optimization and Localization Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Use the first 90 days of observed English performance to improve intent alignment and localize one evidence-selected five-page cohort into Spanish, then Catalan.

**Architecture:** A committed aggregate metrics file drives deterministic page decisions without exposing raw analytics. A translation manifest maps stable `translationKey` values across languages; Astro generates prefixed localized routes with reciprocal canonical and `hreflang` annotations, while human review controls linguistic and factual quality.

**Tech Stack:** Astro content collections, Node.js 22.13.0, Vitest 4.1.10, Search Console, Plausible, App Store Connect, Markdown/MDX.

## Global Constraints

- Wait at least 90 days after the final Phase 2 batch before selecting localization winners, unless a page already has a verified App Store conversion signal.
- Optimization uses observed Search Console, Plausible, and App Store data; it must not invent traffic, ranking, or download estimates.
- English remains canonical for English pages. Spanish uses `/es/`; Catalan uses `/ca/`.
- Translate the homepage plus exactly four acquisition pages in the first localization cohort.
- Select the four pages deterministically by attributed App Store clicks, then organic clicks, then impressions, with canonical path as the tie-breaker.
- Spanish receives human editorial review before Catalan work begins; Catalan receives its own human review.
- Localize meaning, terminology, screenshots, examples, and CTAs; do not ship raw machine translation.
- Do not introduce country/legal/tax claims unless authoritative sources and review dates are recorded.
- Each localized page must have reciprocal `hreflang`, a self-canonical URL, and matching visible content.

---

### Task 1: Aggregate the 90-day scorecard and select the localization cohort

**Files:**
- Create: `landing-page/seo-ops/metrics/english-90-day.json`
- Create: `landing-page/seo-ops/localization/translation-set.json`
- Create: `landing-page/scripts/seo/select-localization-set.mjs`
- Create: `landing-page/tests/seo/select-localization-set.test.mjs`
- Create: `docs/seo/reviews/english-90-day-review.md`

**Interfaces:**
- Consumes: aggregate records `{ path, impressions, organicClicks, appStoreClicks, engagedVisits, indexed }` for the fifteen English routes.
- Produces: `{ generatedAt, sourceWindow, routes: ['/', ...four paths] }` with deterministic ordering.

- [ ] **Step 1: Write failing selection tests**

```js
import { expect, it } from 'vitest';
import { selectLocalizationSet } from '../../scripts/seo/select-localization-set.mjs';

it('always selects home plus four conversion-first pages', () => {
  const rows = [
    { path: '/guides/a/', appStoreClicks: 2, organicClicks: 3, impressions: 40, indexed: true },
    { path: '/guides/b/', appStoreClicks: 0, organicClicks: 30, impressions: 300, indexed: true },
    { path: '/guides/c/', appStoreClicks: 1, organicClicks: 1, impressions: 20, indexed: true },
    { path: '/guides/d/', appStoreClicks: 0, organicClicks: 20, impressions: 200, indexed: true },
    { path: '/guides/e/', appStoreClicks: 0, organicClicks: 10, impressions: 100, indexed: true }
  ];
  expect(selectLocalizationSet(rows).routes).toEqual(['/', '/guides/a/', '/guides/c/', '/guides/b/', '/guides/d/']);
});
```

- [ ] **Step 2: Export and aggregate actual metrics**

Keep raw exports in `landing-page/seo-ops/private/`. Commit only path-level totals for the common 90-day window. Use integer zero for observed zero; add `dataAvailable: false` only when a named system lacked access. Do not include visitor identifiers or query rows that reveal customer data.

- [ ] **Step 3: Implement deterministic selection**

Filter to indexed acquisition pages, sort descending by `appStoreClicks`, then `organicClicks`, then `impressions`, then ascending canonical path, take four, and prepend `/`. Fail when fewer than four indexed acquisition pages exist; do not fill the cohort with unindexed pages.

- [ ] **Step 4: Write the English review**

For each page classify: `expand`, `snippet-test`, `maintain`, `consolidation-review`, or `technical-fix`. Pages with conversion signals are never consolidated solely for low impressions. Pages with zero impressions require indexability and intent review before a content decision.

- [ ] **Step 5: Test and commit the cohort**

Run: `cd landing-page && npm test -- tests/seo/select-localization-set.test.mjs && node scripts/seo/select-localization-set.mjs`
Expected: exactly five unique routes, beginning with `/`.

```bash
git add landing-page/seo-ops/metrics/english-90-day.json landing-page/seo-ops/localization/translation-set.json landing-page/scripts/seo/select-localization-set.mjs landing-page/tests/seo/select-localization-set.test.mjs docs/seo/reviews/english-90-day-review.md
git commit -m "docs(seo): select evidence-based localization cohort"
```

### Task 2: Apply evidence-based English optimizations

**Files:**
- Modify: English content files selected in `docs/seo/reviews/english-90-day-review.md`
- Create: `docs/seo/experiments/english-snippet-tests.md`
- Modify: `docs/seo/content-inventory.md`
- Modify: `landing-page/tests/content/inventory.test.mjs`

**Interfaces:**
- Consumes: explicit classifications and Search Console queries from the 90-day review.
- Produces: versioned title/description/copy/internal-link changes with a measurable rationale.

- [ ] **Step 1: Add tests for preserved intent and route identity**

Keep the exact fifteen-route set, translation keys, primary cluster, and campaign names unchanged. Add assertions that title/description changes remain unique and within existing length contracts.

- [ ] **Step 2: Fix technical and indexing issues first**

For every `technical-fix`, reproduce the canonical, sitemap, robots, response, orphan-link, or rendering failure; add a regression assertion to `validate-dist`; then make the minimum fix. Do not rewrite content to solve a crawl defect.

- [ ] **Step 3: Run controlled snippet tests**

For each `snippet-test`, record old title/description, observed query pattern, new title/description, change date, and evaluation date at least 28 days later. Change title/description only; do not simultaneously rewrite the page body.

- [ ] **Step 4: Expand pages with conversion or strong query evidence**

Add only sections that answer observed queries or remove conversion friction. Cite authoritative sources for date-sensitive claims and preserve the opening answer/summary contract.

- [ ] **Step 5: Review overlap before consolidation**

A `consolidation-review` needs a written intent comparison, selected survivor, internal-link update list, and redirect mapping. Do not remove a page in this task unless the review proves overlapping intent and the redirect test is added.

- [ ] **Step 6: Verify and commit each independent experiment**

Run: `cd landing-page && npm run verify`
Expected: PASS. Use one commit per snippet test, technical fix, expansion, or approved consolidation so results remain attributable.

### Task 3: Add multilingual routing and reciprocal `hreflang`

**Files:**
- Modify: `landing-page/src/content.config.js`
- Modify: `landing-page/src/lib/seo.js`
- Create: `landing-page/src/lib/i18n.js`
- Create: `landing-page/src/pages/[lang]/index.astro`
- Create: `landing-page/src/pages/[lang]/features/[slug].astro`
- Create: `landing-page/src/pages/[lang]/for/[slug].astro`
- Create: `landing-page/src/pages/[lang]/compare/[slug].astro`
- Create: `landing-page/src/pages/[lang]/guides/[slug].astro`
- Create: `landing-page/src/pages/[lang]/tools/[slug].astro`
- Create: `landing-page/tests/seo/i18n.test.mjs`

**Interfaces:**
- Consumes: entries with `lang: en|es|ca` and stable `translationKey`.
- Produces: `localizedPath(entry)`, `buildAlternates(entries)`, self-canonical localized routes, reciprocal alternates, and `x-default` English links.

- [ ] **Step 1: Write failing path and alternate tests**

```js
import { expect, it } from 'vitest';
import { localizedPath, buildAlternates } from '../../src/lib/i18n.js';

it('keeps English at root and prefixes Spanish/Catalan', () => {
  expect(localizedPath({ lang: 'en', cluster: 'guides', slug: 'landlord-expense-tracker' })).toBe('/guides/landlord-expense-tracker/');
  expect(localizedPath({ lang: 'es', cluster: 'guides', slug: 'control-gastos-alquiler' })).toBe('/es/guides/control-gastos-alquiler/');
});

it('returns only reciprocal available translations plus x-default', () => {
  const values = buildAlternates([
    { lang: 'en', path: '/guides/landlord-expense-tracker/' },
    { lang: 'es', path: '/es/guides/control-gastos-alquiler/' }
  ]);
  expect(values.map(x => x.lang)).toEqual(['en', 'es', 'x-default']);
});
```

- [ ] **Step 2: Generalize the content schema**

Change the shared `lang` field to `z.enum(['en','es','ca'])`. Add a `localized` collection loaded with `glob({ pattern: '**/*.{md,mdx}', base: './src/content/localized' })`; its schema includes localized `slug`, original `cluster`, and stable `translationKey`. Enforce unique `lang + translationKey`, one English source per translation key, and no localized `published` entry without its English source.

- [ ] **Step 3: Implement localized static paths**

Have every `[lang]` route query the `localized` collection, filter by matching `cluster` and `lang`, and generate only `es` and `ca` paths; English continues through existing root templates. Reuse AcquisitionLayout, localized breadcrumb labels, CTA copy, and related links that resolve within the same language when translations exist, otherwise to English with an explicit language label.

- [ ] **Step 4: Implement canonical/alternate rules**

Every localized page self-canonicalizes. Emit alternates only for published equivalents; include English as `x-default`; require reciprocity in dist validation. Never canonicalize Spanish or Catalan pages to English when their content is a reviewed localization.

- [ ] **Step 5: Test and commit routing before content**

Run: `cd landing-page && npm test -- tests/seo/i18n.test.mjs && npm run build`
Expected: English build unchanged and no localized routes generated without content.

```bash
git add landing-page/src/content.config.js landing-page/src/lib/seo.js landing-page/src/lib/i18n.js landing-page/src/pages/[lang] landing-page/tests/seo/i18n.test.mjs
git commit -m "feat(seo): add evidence-gated multilingual routing"
```

### Task 4: Localize the selected cohort into Spanish

**Files:**
- Create: `landing-page/src/content/localized/es/` entries for the five `translation-set.json` routes
- Create: `landing-page/src/data/i18n/es.json`
- Modify: `landing-page/src/pages/[lang]/index.astro`
- Create: `landing-page/tests/content/spanish.test.mjs`
- Create: `docs/seo/localization/spanish-review.md`

**Interfaces:**
- Consumes: exact approved English source revision and translation set.
- Produces: five human-reviewed Spanish routes with App Store campaign and analytics language `es`.

- [ ] **Step 1: Define exact shared Spanish UI copy**

```json
{
  "download": "Descargar ManageState para iPhone",
  "summary": "Resumen",
  "related": "Contenido relacionado",
  "faq": "Preguntas frecuentes",
  "home": "Inicio",
  "lastUpdated": "Última actualización"
}
```

- [ ] **Step 2: Write a failing cohort parity test**

Assert Spanish published translation keys exactly equal the five selected keys, every entry records `sourceRevision`, all related links resolve, CTA language is `es`, summaries have 3–5 sentences, and no English paragraph longer than 80 characters remains.

- [ ] **Step 3: Produce human-reviewed Spanish localizations**

Translate meaning and examples, not just words. Use `propietario`, `alquiler`, and regional terminology consistently. Preserve non-advice disclaimers. Date every factual source and avoid Spain-specific legal/tax claims unless the page cites an authoritative Spanish source.

- [ ] **Step 4: Perform editorial and product review**

A fluent reviewer checks accuracy, naturalness, CTA wording, screenshots, metadata, slugs, visible FAQs, links, and claim parity. Record reviewer, date, source revision, and corrections in `spanish-review.md`.

- [ ] **Step 5: Build and verify Spanish routes**

Run: `cd landing-page && npm test -- tests/content/spanish.test.mjs && npm run verify`
Expected: five Spanish routes, reciprocal English/Spanish alternates, valid sitemap entries, and no untranslated long-form body fragments.

- [ ] **Step 6: Commit Spanish localization**

```bash
git add landing-page/src/content/localized/es landing-page/src/data/i18n/es.json landing-page/src/pages/[lang]/index.astro landing-page/tests/content/spanish.test.mjs docs/seo/localization/spanish-review.md
git commit -m "feat(seo): publish reviewed Spanish acquisition cohort"
```

### Task 5: Localize the same cohort into Catalan

**Files:**
- Create: `landing-page/src/content/localized/ca/` entries for the five selected routes
- Create: `landing-page/src/data/i18n/ca.json`
- Create: `landing-page/tests/content/catalan.test.mjs`
- Create: `docs/seo/localization/catalan-review.md`

**Interfaces:**
- Consumes: English source revisions and completed Spanish QA lessons; Spanish is not the translation source.
- Produces: five human-reviewed Catalan routes with analytics language `ca`.

- [ ] **Step 1: Define exact shared Catalan UI copy**

```json
{
  "download": "Descarrega ManageState per a l’iPhone",
  "summary": "Resum",
  "related": "Contingut relacionat",
  "faq": "Preguntes freqüents",
  "home": "Inici",
  "lastUpdated": "Última actualització"
}
```

- [ ] **Step 2: Copy and adapt the parity tests for Catalan**

Require exactly the selected translation keys, `sourceRevision`, valid links, language `ca`, 3–5 sentence summaries, and reciprocal English/Spanish/Catalan alternates.

- [ ] **Step 3: Produce direct English-to-Catalan localizations**

Use consistent Catalan landlord/property terminology, preserve claim scope and disclaimers, and do not introduce Catalonia-specific legal/tax advice without authoritative sources.

- [ ] **Step 4: Complete independent Catalan review**

Record reviewer, date, source revision, terminology decisions, and corrections. Do not reuse the Spanish reviewer approval as Catalan approval.

- [ ] **Step 5: Verify and commit Catalan routes**

Run: `cd landing-page && npm test -- tests/content/catalan.test.mjs && npm run verify`
Expected: five Catalan routes and complete three-language reciprocal alternates.

```bash
git add landing-page/src/content/localized/ca landing-page/src/data/i18n/ca.json landing-page/tests/content/catalan.test.mjs docs/seo/localization/catalan-review.md
git commit -m "feat(seo): publish reviewed Catalan acquisition cohort"
```

### Task 6: Deploy, submit, and establish multilingual monitoring

**Files:**
- Create: `docs/seo/releases/phase-4-localization-launch.md`
- Modify: `docs/seo/content-inventory.md`
- Modify: `landing-page/scripts/seo/validate-dist.mjs`

**Interfaces:**
- Consumes: production localized routes and sitemap.
- Produces: live verification records and a repeatable next-cohort decision process.

- [ ] **Step 1: Extend dist validation**

Require self-canonicals, reciprocal alternates, correct `html lang`, localized CTA labels, unique localized metadata, and sitemap presence. Reject alternates to draft/missing pages.

- [ ] **Step 2: Deploy Spanish first**

Verify live routes, source HTML, links, events, and Search Console URL Inspection. Observe at least one clean deployment cycle before enabling Catalan routes.

- [ ] **Step 3: Deploy Catalan after Spanish validation**

Repeat the same checks and record actual submission/indexing dates.

- [ ] **Step 4: Configure language-segment reporting**

Create Plausible segments for `/es/**` and `/ca/**`; monitor Search Console by page prefix; preserve `language` in App Store click props.

- [ ] **Step 5: Commit the launch record**

```bash
git add docs/seo/releases/phase-4-localization-launch.md docs/seo/content-inventory.md landing-page/scripts/seo/validate-dist.mjs
git commit -m "docs(seo): record multilingual acquisition launch"
```

## Phase 4 Exit Gate

All selected English changes must have an experiment or review record. Exactly five Spanish and five Catalan routes must be live, human-reviewed, self-canonical, reciprocal through `hreflang`, present in the sitemap, and measurable by language. Any translation with unresolved legal, factual, or linguistic concerns remains `review` and out of production.
