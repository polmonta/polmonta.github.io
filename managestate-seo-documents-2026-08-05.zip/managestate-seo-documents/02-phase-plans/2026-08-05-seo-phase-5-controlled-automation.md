# SEO Phase 5: Controlled Draft Automation Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Automate evidence-bound draft preparation and pull-request creation while preserving human editorial approval and prohibiting direct site or platform publication.

**Architecture:** A repository-backed topic queue and append-only run records provide unique topic ownership and retryable state. A scheduled GitHub Action invokes an Anthropic Messages API adapter, validates generated drafts against evidence and duplication rules, and opens a pull request; merging and all external publication remain human actions.

**Tech Stack:** Node.js 22.13.0 native `fetch`, Vitest 4.1.10, Anthropic Messages API, GitHub Actions, JSON, Markdown/MDX.

## Global Constraints

- This phase is ineligible until the explicit Task 1 gate passes with recorded evidence.
- Automation may generate drafts and platform adaptations; it may not deploy the site, merge pull requests, drive a browser, or publish to Medium, Substack, YouTube, GitHub, social networks, or communities.
- Every generated draft remains `status: draft` and outside production routes until human approval changes it.
- Topic IDs are unique; a failed run leaves the topic queued and eligible for retry.
- Only verified public evidence files and approved content briefs may enter the model prompt.
- No raw Search Console exports, private analytics, customer property data, credentials, or personally identifiable data may enter prompts or run artifacts.
- Generated statistics, testimonials, legal claims, tax advice, and unsupported competitor claims are release-blocking failures.
- One scheduled draft attempt per week is the initial maximum.
- `SEO_AUTOMATION_ENABLED` defaults to `false`; absence of the variable disables generation.

---

### Task 1: Implement and record the automation eligibility gate

**Files:**
- Create: `landing-page/scripts/seo/check-automation-eligibility.mjs`
- Create: `landing-page/tests/seo/automation-eligibility.test.mjs`
- Create: `docs/seo/reviews/automation-eligibility.md`
- Modify: `landing-page/package.json`

**Interfaces:**
- Consumes: publication ledger, Phase 3 review, content validation history, and incident record.
- Produces: `{ eligible, checks }` and a non-zero CLI exit when automation must remain disabled.

- [ ] **Step 1: Write failing gate tests**

```js
import { expect, it } from 'vitest';
import { evaluateEligibility } from '../../scripts/seo/check-automation-eligibility.mjs';

it('rejects automation without repeated verified manual runs', () => {
  const result = evaluateEligibility({ published: 3, verified: 3, editorialPasses: 3, criticalIncidents: 0, qualifiedResults: 1 });
  expect(result.eligible).toBe(false);
});

it('accepts a clean repeated workflow', () => {
  const result = evaluateEligibility({ published: 8, verified: 8, editorialPasses: 8, criticalIncidents: 0, qualifiedResults: 2 });
  expect(result.eligible).toBe(true);
});
```

- [ ] **Step 2: Implement five mandatory checks**

Require at least eight completed manual publications; all eight public URLs verified; all eight editorial reviews passed; zero unresolved critical factual/privacy incidents; and at least two publications with a qualified referral visit or App Store click. These are safety/readiness checks, not traffic promises.

- [ ] **Step 3: Generate the eligibility review from actual records**

Document each check, evidence source, observed value, pass/fail, reviewer, and date. If any check fails, keep automation disabled and stop this plan after committing the review.

- [ ] **Step 4: Add and run the gate command**

```json
"check:automation-eligibility": "node scripts/seo/check-automation-eligibility.mjs"
```

Run: `cd landing-page && npm test -- tests/seo/automation-eligibility.test.mjs && npm run check:automation-eligibility`
Expected: PASS only when the real ledger meets all five conditions.

- [ ] **Step 5: Commit the gate**

```bash
git add landing-page/scripts/seo/check-automation-eligibility.mjs landing-page/tests/seo/automation-eligibility.test.mjs landing-page/package.json docs/seo/reviews/automation-eligibility.md
git commit -m "feat(seo): gate content draft automation on evidence"
```

### Task 2: Create the unique topic queue and retryable run state

**Files:**
- Create: `landing-page/seo-ops/automation/topics.json`
- Create: `landing-page/seo-ops/automation/runs/.gitkeep`
- Create: `landing-page/scripts/seo/automation-state.mjs`
- Create: `landing-page/tests/seo/automation-state.test.mjs`

**Interfaces:**
- Consumes: topics `{ topicId, primaryQuery, intent, cluster, sourcePaths, evidenceIds, status, attempts }`.
- Produces: `claimNextTopic`, `completeRun`, and `failRun`; states `queued|claimed|drafted|retired`.

- [ ] **Step 1: Write failing uniqueness/retry tests**

Assert duplicate `topicId` fails; `claimNextTopic` selects one queued topic by approved score/order; `failRun` increments attempts but returns status to `queued`; `completeRun` sets `drafted`; and no second claim succeeds while a current claim is active.

- [ ] **Step 2: Implement atomic state updates**

Write temporary JSON and atomically rename. Include `runId`, ISO timestamps, and factual error codes. A stale claim older than 24 hours may return to queued only through an explicit `recover-stale <runId>` command that records the recovery.

- [ ] **Step 3: Seed only approved topics**

Populate the initial queue from the validated Phase 3 topic queue. Each record must reference live ManageState paths and verified evidence IDs. Do not add a city/location multiplier.

- [ ] **Step 4: Run state tests**

Run: `cd landing-page && npm test -- tests/seo/automation-state.test.mjs`
Expected: PASS, including simulated crash/retry behavior.

- [ ] **Step 5: Commit queue state**

```bash
git add landing-page/seo-ops/automation/topics.json landing-page/seo-ops/automation/runs/.gitkeep landing-page/scripts/seo/automation-state.mjs landing-page/tests/seo/automation-state.test.mjs
git commit -m "feat(seo): add retryable unique topic queue"
```

### Task 3: Implement an evidence-bound Anthropic draft generator

**Files:**
- Create: `landing-page/scripts/seo/anthropic-client.mjs`
- Create: `landing-page/scripts/seo/build-draft-prompt.mjs`
- Create: `landing-page/scripts/seo/generate-draft.mjs`
- Create: `landing-page/tests/seo/draft-generator.test.mjs`
- Create: `landing-page/tests/fixtures/anthropic-draft-response.json`

**Interfaces:**
- Consumes: claimed topic, approved brief/source-page excerpts, verified evidence records, `ANTHROPIC_API_KEY`, and required `SEO_CLAUDE_MODEL`.
- Produces: one Markdown draft plus run metadata; the client uses `generateDraft({ model, apiKey, prompt, fetchImpl })`.

- [ ] **Step 1: Write failing prompt-boundary tests**

Assert prompts contain topic ID, primary query, intent, allowed evidence IDs, exact evidence text, required summary/answer/CTA sections, and explicit prohibitions. Assert prompts do not include files under `seo-ops/private`, raw analytics, or evidence records not referenced by the topic.

- [ ] **Step 2: Write a mocked API test**

Mock `fetch`; assert POST to `https://api.anthropic.com/v1/messages`, headers `x-api-key`, `anthropic-version`, and JSON body using the required model. Test 429, timeout, malformed JSON, and empty content as retryable failures.

- [ ] **Step 3: Implement the prompt builder**

Require the model to return Markdown with frontmatter `topicId`, `primaryQuery`, `intent`, `status: draft`, `evidenceIds`, and `generatedAt`. Require direct opening answer, 3–5 sentence summary, distinct sections, visible source-grounded FAQs only when provided, related links, and App Store CTA. State that the model must omit a claim rather than infer it.

- [ ] **Step 4: Implement the API client and generator**

Use native fetch with a 60-second timeout and no logging of API keys or full prompts. Fail closed when `SEO_AUTOMATION_ENABLED !== 'true'`, eligibility fails, model/key is absent, or no topic is queued. Write output to `landing-page/seo-ops/generated/<runId>/<topicId>.md`, not to a production content collection.

- [ ] **Step 5: Run mocked tests**

Run: `cd landing-page && npm test -- tests/seo/draft-generator.test.mjs`
Expected: PASS without a real API call.

- [ ] **Step 6: Commit the generator**

```bash
git add landing-page/scripts/seo/anthropic-client.mjs landing-page/scripts/seo/build-draft-prompt.mjs landing-page/scripts/seo/generate-draft.mjs landing-page/tests/seo/draft-generator.test.mjs landing-page/tests/fixtures/anthropic-draft-response.json
git commit -m "feat(seo): generate evidence-bound content drafts"
```

### Task 4: Add release-blocking generated-draft quality checks

**Files:**
- Create: `landing-page/scripts/seo/validate-generated-draft.mjs`
- Create: `landing-page/tests/seo/generated-draft-quality.test.mjs`
- Modify: `landing-page/scripts/seo/generate-draft.mjs`

**Interfaces:**
- Consumes: generated Markdown, approved evidence, existing English content corpus, and topic record.
- Produces: `{ valid, errors }`; only valid drafts may enter a pull request.

- [ ] **Step 1: Write failing quality fixtures**

Cover fabricated percentage/statistic, unknown testimonial, unsupported `bank-grade`/`guaranteed`, city-swapped thin copy, missing opening answer, summary outside 3–5 sentences, invalid internal link, duplicate intent, body similarity above 70%, missing evidence citation, and production `status: published`.

- [ ] **Step 2: Implement deterministic checks**

Validate frontmatter identity, allowed claims/evidence IDs, prohibited absolutes, numeric claims against exact evidence text, internal links against built route inventory, body shingle similarity, section contract, and `status: draft`. Do not use another model to approve the first model's output.

- [ ] **Step 3: Integrate fail/retry behavior**

A quality failure writes a compact run record with error codes, deletes no previous artifacts, and returns the topic to `queued`. It never marks the keyword/topic used and never opens a pull request.

- [ ] **Step 4: Run quality tests**

Run: `cd landing-page && npm test -- tests/seo/generated-draft-quality.test.mjs`
Expected: every unsafe fixture fails for the expected reason and a clean fixture passes.

- [ ] **Step 5: Commit quality gates**

```bash
git add landing-page/scripts/seo/validate-generated-draft.mjs landing-page/scripts/seo/generate-draft.mjs landing-page/tests/seo/generated-draft-quality.test.mjs landing-page/tests/fixtures
git commit -m "test(seo): block unsafe generated drafts"
```

### Task 5: Open a human-review pull request on a weekly schedule

**Files:**
- Create: `.github/workflows/seo-draft.yml`
- Create: `landing-page/scripts/seo/prepare-draft-pr.mjs`
- Create: `docs/seo/automation-runbook.md`
- Modify: `landing-page/package.json`

**Interfaces:**
- Consumes: GitHub variables `SEO_AUTOMATION_ENABLED`, `SEO_CLAUDE_MODEL`; secret `ANTHROPIC_API_KEY`; eligible queue.
- Produces: one branch and pull request containing a draft artifact, state transition, validation report, and reviewer checklist.

- [ ] **Step 1: Implement dry-run PR preparation**

`prepare-draft-pr.mjs` runs eligibility, claims one topic, generates/validates one draft, writes a run JSON record, marks the topic `drafted`, and prints a PR title/body. `--dry-run` must make no API call and no state change.

- [ ] **Step 2: Add the disabled-by-default workflow**

Configure `workflow_dispatch` and weekly cron, `concurrency: seo-draft-generator`, `contents: write`, and `pull-requests: write`. Check out main, use Node 22.13.0, run `npm ci` in `landing-page`, assert the repository variable equals `true`, run eligibility and tests, generate one draft, create branch `automation/seo-draft-${GITHUB_RUN_ID}`, commit exact generated/state/run files, push, and call `gh pr create` with `GITHUB_TOKEN`.

- [ ] **Step 3: Add the PR review checklist**

Require a human to verify query intent, factual claims, evidence IDs, duplicated passages, links, screenshots/examples, legal/tax language, metadata, and conversion relevance. Approval does not publish the draft; a separate human implementation converts it into the appropriate content collection and reruns normal Phase 2 gates.

- [ ] **Step 4: Document kill/recovery procedures**

The runbook must show how to set `SEO_AUTOMATION_ENABLED=false`, rotate the API key, recover a stale claim, retry a failed topic, close/reject a PR, and inspect run records without exposing prompts or secrets.

- [ ] **Step 5: Test workflow locally and commit**

Run:

```bash
cd landing-page
node scripts/seo/prepare-draft-pr.mjs --dry-run
npm test
npm run check:automation-eligibility
```

Expected: dry run identifies the next eligible topic but changes no files; tests and gate PASS.

```bash
git add .github/workflows/seo-draft.yml landing-page/scripts/seo/prepare-draft-pr.mjs landing-page/package.json docs/seo/automation-runbook.md
git commit -m "ci(seo): open weekly human-reviewed draft PRs"
```

### Task 6: Observe four runs and decide whether to continue

**Files:**
- Create: `docs/seo/reviews/automation-four-run-review.md`
- Modify: `docs/seo/automation-runbook.md`
- Modify: `landing-page/seo-ops/automation/topics.json`

**Interfaces:**
- Consumes: four scheduled/manual workflow run records and reviewer outcomes.
- Produces: explicit `continue`, `revise`, or `disable` decision; direct publishing remains prohibited in all outcomes.

- [ ] **Step 1: Keep the weekly cap for four runs**

Do not increase frequency during observation. Record generation success, validation errors, retries, review corrections, time saved, accepted/rejected status, and any factual/privacy incident.

- [ ] **Step 2: Review correction patterns**

Group corrections by prompt defect, missing evidence, intent mismatch, duplication, tone, links, and factual accuracy. Fix deterministic validators before changing the model prompt when possible.

- [ ] **Step 3: Apply the safety decision**

- `continue`: all accepted drafts passed evidence/privacy checks and reviewer effort decreased.
- `revise`: no critical incident occurred, but repeated correctable validation/editorial defects remain.
- `disable`: any sensitive-data leak, fabricated evidence reaching review, repeated duplicate content, or unresolved state corruption occurred.

- [ ] **Step 4: Keep external publishing manual**

Even a `continue` decision does not authorize direct platform APIs or browser automation. That would require a new design amendment and separate approval.

- [ ] **Step 5: Commit the review and configuration decision**

```bash
git add docs/seo/reviews/automation-four-run-review.md docs/seo/automation-runbook.md landing-page/seo-ops/automation/topics.json
git commit -m "docs(seo): review controlled draft automation"
```

## Phase 5 Exit Gate

The phase is complete only after eligibility evidence, queue uniqueness, retry behavior, mocked API tests, deterministic quality gates, disabled-by-default workflow, human PR review, and four-run observation are documented. Completion does not grant permission for autonomous publishing or merging.
