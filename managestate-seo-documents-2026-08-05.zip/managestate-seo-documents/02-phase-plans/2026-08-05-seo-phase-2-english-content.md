# SEO Phase 2: English Acquisition Content Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Publish fifteen distinct, internally linked English acquisition pages that satisfy commercial landlord search intents and drive measurable App Store visits.

**Architecture:** Astro content collections hold validated page metadata, summaries, FAQs, related links, and editorial status. Shared static route templates render features, audiences, comparisons, guides, and tools; only the ROI calculator hydrates as a React island.

**Tech Stack:** Astro content collections, Markdown/MDX, React 19.2.0, Vitest 4.1.10, Node.js 22.13.0, static CSV assets, Search Console.

## Global Constraints

- Phase 1 exit gate must pass before starting.
- Publish exactly the fifteen English acquisition routes approved in the design, in addition to `/`.
- Every page must answer its query in the opening paragraph and display a three-to-five-sentence quotable summary.
- Every page must have distinct intent, body copy, title, description, H1, examples, and internal-link purpose.
- Use only verified product claims, reviews, testimonials, screenshots, and statistics.
- Do not create city/location pages, fake comparisons, aggregate-rating schema without evidence, or raw keyword-swapped templates.
- Every page ends with a working `Download ManageState for iPhone` CTA and emits `app_store_click`.
- FAQ schema is allowed only when the same questions and answers are visible and currently eligible under search-engine policy.
- Editorial review is mandatory before `status: published`.

---

### Task 1: Create the acquisition content schema and static route templates

**Files:**
- Create: `landing-page/src/content.config.js`
- Create: `landing-page/src/layouts/AcquisitionLayout.astro`
- Create: `landing-page/src/components/content/SummaryBlock.astro`
- Create: `landing-page/src/components/content/Breadcrumbs.astro`
- Create: `landing-page/src/components/content/RelatedContent.astro`
- Create: `landing-page/src/components/content/VisibleFaq.astro`
- Create: `landing-page/src/pages/features/[slug].astro`
- Create: `landing-page/src/pages/for/[slug].astro`
- Create: `landing-page/src/pages/compare/[slug].astro`
- Create: `landing-page/src/pages/guides/[slug].astro`
- Create: `landing-page/src/pages/tools/[slug].astro`
- Create: `landing-page/tests/content/content-contract.test.mjs`

**Interfaces:**
- Consumes: collection entries with `{ title, description, h1, summary, intent, cluster, campaign, status, updatedAt, related, faqs }`.
- Produces: static routes and `getAcquisitionPaths(collectionName)`; only `status: published` entries enter production routes or the sitemap.

- [ ] **Step 1: Write a failing content-contract test**

Assert that: allowed collections are `features`, `audiences`, `comparisons`, `guides`, and `tools`; language is `en`; summary length is 3–5; status is `draft|review|published`; related links are absolute site paths; campaign matches `/^website-(features|audiences|comparisons|guides|tools)$/`; and published entries contain at least one related link plus a non-empty opening answer.

- [ ] **Step 2: Run the test and verify failure**

Run: `cd landing-page && npm test -- tests/content/content-contract.test.mjs`
Expected: FAIL because the content configuration does not exist.

- [ ] **Step 3: Implement the collection schema**

Use `defineCollection`, `z`, and the Astro `glob` loader. Give every collection its own directory under `src/content/`. Include `translationKey` now, equal to a stable English slug, so Phase 4 can add localizations without changing identifiers.

```js
const base = z.object({
  title: z.string().min(30).max(70),
  description: z.string().min(110).max(165),
  h1: z.string().min(10).max(90),
  summary: z.array(z.string().min(20)).min(3).max(5),
  openingAnswer: z.string().min(80),
  intent: z.string().min(10),
  cluster: z.enum(['features', 'audiences', 'comparisons', 'guides', 'tools']),
  campaign: z.enum(['website-features', 'website-audiences', 'website-comparisons', 'website-guides', 'website-tools']),
  lang: z.literal('en'),
  translationKey: z.string().regex(/^[a-z0-9-]+$/),
  status: z.enum(['draft', 'review', 'published']),
  updatedAt: z.coerce.date(),
  related: z.array(z.string().startsWith('/')).min(1),
  faqs: z.array(z.object({ question: z.string(), answer: z.string() })).default([])
});
```

- [ ] **Step 4: Implement shared static rendering**

`AcquisitionLayout` renders breadcrumbs, H1, opening answer, SummaryBlock, body slot, visible FAQs, related content, and AppStoreLink. Route templates call `getCollection`, filter `status === 'published'`, and use `render(entry)`; no route uses client-side data fetching.

- [ ] **Step 5: Run schema tests and an empty build**

Run: `cd landing-page && npm test -- tests/content/content-contract.test.mjs && npm run build`
Expected: PASS with no acquisition entries yet and no malformed routes.

- [ ] **Step 6: Commit the content platform**

```bash
git add landing-page/src/content.config.js landing-page/src/layouts/AcquisitionLayout.astro landing-page/src/components/content landing-page/src/pages/features landing-page/src/pages/for landing-page/src/pages/compare landing-page/src/pages/guides landing-page/src/pages/tools landing-page/tests/content/content-contract.test.mjs
git commit -m "feat(seo): add validated acquisition content platform"
```

### Task 2: Publish feature, audience, and spreadsheet-comparison pages

**Files:**
- Create: `landing-page/src/content/features/financial-control.md`
- Create: `landing-page/src/content/features/document-management.md`
- Create: `landing-page/src/content/features/profitability-roi.md`
- Create: `landing-page/src/content/features/tax-export.md`
- Create: `landing-page/src/content/audiences/small-landlords.md`
- Create: `landing-page/src/content/audiences/first-time-landlords.md`
- Create: `landing-page/src/content/audiences/growing-property-investors.md`
- Create: `landing-page/src/content/comparisons/landlord-app-vs-spreadsheets.md`
- Create: `landing-page/tests/content/core-pages.test.mjs`

**Interfaces:**
- Consumes: verified Phase 0 product claims and screenshots.
- Produces: eight published static routes with campaign groups `website-features`, `website-audiences`, and `website-comparisons`.

- [ ] **Step 1: Add a failing eight-route inventory test**

Assert exact canonical paths, unique metadata, no phrase `trusted by thousands`, no unsupported `bank-grade`, no competitor claim without a cited source, and at least two cross-cluster internal links per page.

- [ ] **Step 2: Create the four feature briefs and copy**

Use these exact metadata targets:

| Route | Title | H1 | Required sections |
|---|---|---|---|
| `/features/financial-control/` | `Rental Property Financial Tracking | ManageState` | `Keep rental income and expenses under control` | income/expense workflow; categorization; portfolio view; spreadsheet pain; App Store CTA |
| `/features/document-management/` | `Rental Property Document Organizer | ManageState` | `Keep property documents with the property they belong to` | document types; retrieval workflow; reminders only if verified; privacy link; CTA |
| `/features/profitability-roi/` | `Rental Property ROI and Profitability Tracking | ManageState` | `Understand how each rental property is performing` | gross vs net; inputs; portfolio comparison; calculator link; CTA |
| `/features/tax-export/` | `Rental Property Tax Export for Landlords | ManageState` | `Organize rental records before tax time` | recorded data; verified export formats; accountant handoff; non-advice disclaimer; CTA |

Each file must include a distinct 3–5 sentence summary and one concrete workflow example. Tax copy must state that ManageState does not provide tax advice.

- [ ] **Step 3: Create the three audience briefs and copy**

| Route | Title | H1 | Required sections |
|---|---|---|---|
| `/for/small-landlords/` | `Property Management App for Small Landlords | ManageState` | `Property management for landlords with 1–5 properties` | audience problems; daily/monthly workflow; feature fit; when enterprise software is excessive; CTA |
| `/for/first-time-landlords/` | `Property Management App for First-Time Landlords` | `Start your first rental with organized records` | setup checklist; income/expense habit; documents; performance; CTA |
| `/for/growing-property-investors/` | `Rental Portfolio App for Growing Property Investors` | `Move beyond one spreadsheet as your portfolio grows` | 5–25 property context; consistent records; per-property performance; limits stated honestly; CTA |

Do not claim ManageState replaces accountants, banks, legal advisers, or enterprise property managers.

- [ ] **Step 4: Create the factual spreadsheet comparison**

`/compare/landlord-app-vs-spreadsheets/` must compare setup, mobile entry, document association, calculations, exports, and maintenance. Include a section titled `When a spreadsheet may still be enough` and avoid declaring ManageState universally superior.

- [ ] **Step 5: Build and test the first batch**

Run: `cd landing-page && npm run build && npm test -- tests/content/core-pages.test.mjs && npm run check:dist`
Expected: all eight routes exist, metadata is unique, and internal links resolve.

- [ ] **Step 6: Commit the first content batch**

```bash
git add landing-page/src/content/features landing-page/src/content/audiences landing-page/src/content/comparisons landing-page/tests/content/core-pages.test.mjs
git commit -m "feat(seo): publish core landlord acquisition pages"
```

### Task 3: Publish five query-answering guides

**Files:**
- Create: `landing-page/src/content/guides/property-management-app-for-small-landlords.md`
- Create: `landing-page/src/content/guides/landlord-expense-tracker.md`
- Create: `landing-page/src/content/guides/rental-income-expense-tracker.md`
- Create: `landing-page/src/content/guides/rental-property-document-organizer.md`
- Create: `landing-page/src/content/guides/landlord-tax-record-app.md`
- Create: `landing-page/tests/content/guides.test.mjs`

**Interfaces:**
- Consumes: verified Search Console questions when available; otherwise factual App Store/support questions recorded in the evidence register.
- Produces: five Article-eligible guides with visible source-grounded FAQs and deep links to matching features/tools.

- [ ] **Step 1: Write a failing guide-quality test**

For each guide assert: opening answer is at least 80 characters; 3–5 summary sentences; updated date; at least three meaningful H2 sections; at least two related links; one App Store CTA; and no two body files have normalized similarity above 70% using 5-word shingles.

- [ ] **Step 2: Write the five distinct guide briefs**

| Guide | Search answer and mandatory sections |
|---|---|
| Property management app for small landlords | selection criteria; small-landlord workflow; essential vs enterprise features; iPhone considerations; decision checklist |
| Landlord expense tracker | what to record; repeatable entry habit; categories without tax advice; receipt/document association; monthly review |
| Rental income and expense tracker | income and expense model; per-property records; cash-flow review; common spreadsheet errors; app workflow |
| Rental property document organizer | document inventory; naming and retrieval; renewal/expiry workflow only if verified; privacy practices; maintenance schedule |
| Landlord tax record app | year-round organization; accountant-ready export only as verified; record completeness; jurisdiction warning; questions for an accountant |

- [ ] **Step 3: Write query-first copy and visible FAQs**

The first paragraph directly answers the query. FAQ questions must be copied from a verified source record and linked in editorial notes. If fewer verified questions exist, publish fewer FAQs rather than inventing them.

- [ ] **Step 4: Add Article and eligible FAQ schema**

Use visible updated dates and organization author. Omit FAQ schema when policy eligibility or source evidence is uncertain; the visible FAQ may remain without schema.

- [ ] **Step 5: Build and run guide-quality checks**

Run: `cd landing-page && npm run build && npm test -- tests/content/guides.test.mjs && npm run check:dist`
Expected: all five routes pass uniqueness, link, and schema checks.

- [ ] **Step 6: Commit the guide batch**

```bash
git add landing-page/src/content/guides landing-page/tests/content/guides.test.mjs landing-page/src/lib/schema.js landing-page/src/layouts/AcquisitionLayout.astro
git commit -m "feat(seo): publish landlord workflow guides"
```

### Task 4: Build the ROI calculator and expense template tools

**Files:**
- Create: `landing-page/src/lib/roi.js`
- Create: `landing-page/src/components/tools/RoiCalculator.jsx`
- Create: `landing-page/src/content/tools/rental-property-roi-calculator.mdx`
- Create: `landing-page/src/content/tools/rental-income-expense-template.md`
- Create: `landing-page/public/downloads/rental-income-expense-template.csv`
- Create: `landing-page/tests/tools/roi.test.mjs`
- Create: `landing-page/tests/tools/template.test.mjs`

**Interfaces:**
- Consumes: annual rent, annual operating expenses, purchase price, and cash invested as non-negative numbers.
- Produces: `calculatePropertyRoi(input): { netIncome, grossYieldPct, netYieldPct, cashOnCashPct }` and a static CSV template.

- [ ] **Step 1: Write failing ROI calculation tests**

```js
import { expect, it } from 'vitest';
import { calculatePropertyRoi } from '../../src/lib/roi.js';

it('calculates standard rental metrics', () => {
  expect(calculatePropertyRoi({ annualRent: 24000, annualExpenses: 6000, purchasePrice: 300000, cashInvested: 90000 })).toEqual({
    netIncome: 18000,
    grossYieldPct: 8,
    netYieldPct: 6,
    cashOnCashPct: 20
  });
});

it('rejects zero denominators and negative inputs', () => {
  expect(() => calculatePropertyRoi({ annualRent: 1, annualExpenses: -1, purchasePrice: 0, cashInvested: 0 })).toThrow();
});
```

- [ ] **Step 2: Implement pure calculations and the React island**

Round percentages to two decimals. Label results as estimates and exclude financing, taxes, appreciation, vacancy, or jurisdiction-specific assumptions unless the user enters them as operating expenses. Hydrate only the calculator with `client:visible`.

- [ ] **Step 3: Create the exact CSV template**

Use this header and one example row clearly marked as an example:

```csv
property,date,type,category,description,amount,currency,document_reference
Example Apartment,2026-01-05,expense,maintenance,Example plumbing repair,125.00,USD,receipt-001
```

Explain each field, advise users to delete the example row, and state that categories are organizational rather than tax advice.

- [ ] **Step 4: Add tool metadata and internal links**

The calculator links to profitability/ROI and small-landlord pages. The template links to financial control, expense tracker, and tax-record guide. Both use campaign `website-tools` and cluster `tools`.

- [ ] **Step 5: Test, build, and keyboard-check the tools**

Run: `cd landing-page && npm test -- tests/tools && npm run build && npm run check:dist`
Expected: calculations and CSV contract PASS; calculator labels and results are keyboard accessible.

- [ ] **Step 6: Commit the tools**

```bash
git add landing-page/src/lib/roi.js landing-page/src/components/tools/RoiCalculator.jsx landing-page/src/content/tools landing-page/public/downloads/rental-income-expense-template.csv landing-page/tests/tools
git commit -m "feat(seo): add landlord ROI and expense tools"
```

### Task 5: Enforce the fifteen-page inventory and launch in batches

**Files:**
- Create: `landing-page/scripts/seo/validate-content.mjs`
- Create: `landing-page/tests/content/inventory.test.mjs`
- Create: `docs/seo/content-inventory.md`
- Create: `docs/seo/releases/phase-2-launch-log.md`
- Modify: `landing-page/package.json`
- Modify: `landing-page/scripts/seo/validate-dist.mjs`

**Interfaces:**
- Consumes: all content collections and built routes.
- Produces: release-blocking content validation and an indexing log for three launch batches.

- [ ] **Step 1: Define the exact expected route set in a failing test**

Hard-code the fifteen approved paths from the design and assert exact equality against published acquisition routes. Also assert no route contains a city/country slug and every page has at least one inbound link from another acquisition page.

- [ ] **Step 2: Implement content validation**

Validate frontmatter, duplicate target intent, duplicate metadata, prohibited unsupported phrases, orphan pages, broken related links, missing CTA data, and summary length. Add `check:content` and place it before the build in `verify`.

- [ ] **Step 3: Document inventory ownership**

For each route record owner, intent, cluster, target query, evidence sources, status, publication batch, and review date. Values must match committed content; do not enter projected rankings or traffic.

- [ ] **Step 4: Release three controlled batches**

- Batch A: four feature pages plus small-landlord page.
- Batch B: remaining audience pages, comparison, and five guides.
- Batch C: two tools.

After each deployment, confirm HTTP 200, canonical, sitemap presence, internal links, App Store click event, and Search Console URL Inspection. Record actual deployment/index-request dates in the launch log.

- [ ] **Step 5: Run final Phase 2 verification**

Run: `cd landing-page && npm run verify`
Expected: exactly fifteen acquisition routes, no orphans, no duplicate metadata/intents, and all static checks PASS.

- [ ] **Step 6: Commit inventory and release tooling**

```bash
git add landing-page/scripts/seo/validate-content.mjs landing-page/scripts/seo/validate-dist.mjs landing-page/tests/content/inventory.test.mjs landing-page/package.json docs/seo/content-inventory.md docs/seo/releases/phase-2-launch-log.md
git commit -m "test(seo): enforce English acquisition inventory"
```

## Phase 2 Exit Gate

Proceed only when all fifteen routes are live, canonical, in the sitemap, internally linked, content-validated, editorially reviewed, and submitted in Search Console. Verify the ROI calculator and CSV download, inspect all CTAs and event fields, and record deployment/indexing status without claiming rankings that have not occurred.
