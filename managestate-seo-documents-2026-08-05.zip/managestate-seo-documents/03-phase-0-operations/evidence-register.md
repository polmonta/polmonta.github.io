# ManageState SEO evidence register

**Verification date:** 2026-08-05
**Scope:** Task 4 customer testimonials, product claims, and screenshots
**Policy:** Only evidence with a source, an applicable approval or consent record, and a wording that matches the shipping behavior may be rendered. Empty collections are intentional when provenance is unavailable.

## Inventory decision

| Evidence category | Accepted records | Data file | Decision |
| --- | ---: | --- | --- |
| Customer testimonials | 0 | `landing-page/src/data/evidence/customer-testimonials.json` | Empty: no owner-supplied source record or publication consent was provided. |
| Product claims | 3 | `landing-page/src/data/evidence/product-claims.json` | Accepted only for behavior directly verified in the shipping app code. |
| Screenshots | 0 | `landing-page/src/data/evidence/screenshots.json` | Empty: no captured app version, provenance record, or approval date could be proven. |

The existing public App Store review inventory in `landing-page/src/data/evidence/app-store-reviews.json` is outside this task and was not converted into a customer testimonial.

## Accepted evidence

### Product claims

These records use repository-relative source paths and were checked against the shipping app on 2026-08-05. They describe behavior, not customer outcomes, adoption, security levels, tax results, or plan terms.

| ID | Exact wording | Verification source | Status |
| --- | --- | --- | --- |
| `claim-monthly-financial-summary` | “ManageState calculates monthly income, expenses, and net income from property transactions.” | `src/services/propertyService.js:38-45, 65-88` | `verified` |
| `claim-property-document-storage` | “ManageState can upload documents for a property and save their document metadata.” | `src/services/propertyService.js:225-298` | `verified` |
| `claim-xlsx-data-export` | “ManageState can export property, transaction, recurring-item, and monthly-summary data as an XLSX workbook.” | `src/services/exportService.js:31-43, 144-167, 169-213, 233-393, 395-428` | `verified` |

Each accepted claim has `status: "verified"`, `verified: true`, the exact wording above, the source object, and `verificationDate: "2026-08-05"` in `product-claims.json`.

### Customer testimonials

None accepted. An accepted testimonial would require a stable ID, exact approved quote, approved display name or initials, source-record location, explicit publication-consent status, approval date, allowed languages, and `verified: true`. No such owner records were supplied, so `customer-testimonials.json` remains `[]`.

### Screenshots

None accepted. `landing-page/public/hero-tilted.png` and `landing-page/public/hero-mockup.png` exist, but repository history only records them as part of the landing-page baseline; it does not provide a captured app version, provenance record, or approval date. `screenshots.json` therefore remains `[]`.

## Owner-directed retention exception

**Decision date:** 2026-08-05

Per the owner's ruling, the current personally received testimonial copy and the
CTA adoption sentence remain rendered in `landing-page/src/App.jsx` unchanged in
this Phase 0 fix wave. This is an explicit content-retention exception, not a
validator approval. The records remain outside `customer-testimonials.json` and
`product-claims.json`; no source record, publication consent, approval date,
allowed-language record, or adoption evidence is fabricated.

### Retained testimonial copy

The following display identities, handles, and body copy are preserved exactly as
currently embedded at `landing-page/src/App.jsx:49-73`:

| Display identity | Handle | Exact retained copy |
| --- | --- | --- |
| `Charles M.` | `@charles_prop` | `Finally left Excel behind. ManageState saves me hours every month.` |
| `Laura G.` | `@laura_invest` | `The tax export feature is a wonder. Highly recommended.` |
| `David R.` | `@david_rent` | `I have 3 apartments and now I control everything from my mobile. Very intuitive.` |
| `Anna P.` | `@anna_host` | `The contract expiration alerts saved my life.` |

These retained strings are not counted among the **0** validator-approved
customer testimonials. Their generated avatar URLs are also not provenance.

### Retained adoption copy

The CTA paragraph at `landing-page/src/App.jsx:213-214` remains unchanged:

> `Join thousands of property owners who already use ManageState. Start your free trial today.`

The “Join thousands of property owners” statement is retained by owner direction,
but it is not recorded as a verified claim, is not included in the three
code-verified product claims, and must not be described as validator-approved
evidence.

## Rejected or unverified evidence

### Other customer and social proof candidates

- “Trusted by property owners worldwide” at `landing-page/src/App.jsx:147-151` has no customer-count or geographic evidence and is not accepted.
- The retained testimonial and adoption copy above remain unverified content under the owner-directed exception; they are not rejected or removed in this fix wave.

### Product-claim candidates

| Candidate wording or topic | Source | Decision and reason |
| --- | --- | --- |
| “Income and expenses up to date. Automated categorization and clear view of your cash flow.” | `landing-page/src/App.jsx:20-21` | Rejected as written. The shipping code verifies monthly totals, but not the “up to date” guarantee or automated categorization wording. The narrower verified monthly-summary claim is recorded above. |
| “Contracts, insurance, and deposits in one secure place.” | `landing-page/src/App.jsx:27-28` | Rejected as written. Upload and metadata storage are verified, but security level and the listed document categories are not proven by the available evidence. |
| “Automatic calculations of net and gross profitability.” | `landing-page/src/App.jsx:34-36` | Rejected. The code calculates net income; `README.md:93-98, 151-154` marks ROI calculations as unimplemented/planned. Gross profitability and ROI are not accepted. |
| “Export your data in 1 click for your tax return. Everything ready for your accountant.” | `landing-page/src/App.jsx:41-42`; FAQ wording at `landing-page/src/App.jsx:82-83` | Rejected. `src/services/exportService.js:395-428` verifies an XLSX export and sharing flow, not tax-return preparation, CSV/PDF output, deductibility, or an accountant/legal outcome. |
| “No. You have a Free Plan without a card and an ad-supported option to start at no cost.” | `landing-page/src/App.jsx:86-87` | Rejected. The available code contains entitlement gates, but no approved source proves card requirements, advertising, or the public plan wording. |
| “Bank-grade encryption, cloud backups, and total access control.” | `landing-page/src/App.jsx:90-91` | Rejected. `app.config.js:50-59` contains an Apple encryption declaration flag, not a security-level or control audit. No “bank-grade” or equivalent claim is inferred. |
| Supported-device marketing claim | `app.config.js:50-73`; landing CTA at `landing-page/src/App.jsx:125-129` | Unverified for public marketing. The config declares iOS and Android targets (and iPad support), but no approved App Store listing or release/device matrix was supplied for a public support claim. |

## Owner-input-needed evidence

1. Supply source records and publication consent for any customer testimonial, including approval date, allowed languages, and the exact quote/name or initials that may be published.
2. Supply a provenance record for each marketing screenshot: public asset path, captured app version/build, capture date, approval date, and the claims visibly supported by the image.
3. Supply an authoritative current App Store listing or release record before adding plan/card terms, supported-device coverage, tax/export outcomes, or security language. Do not infer any of those outcomes from landing-page copy, a build flag, or an unapproved README statement.

Until those inputs exist, future work must render only the accepted code-verified claims above and the separately inventoried public App Store review records.
