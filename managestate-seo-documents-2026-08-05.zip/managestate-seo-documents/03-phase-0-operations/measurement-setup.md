# Measurement setup and owner runbook

**Baseline date:** 2026-08-05
**Status:** baseline recorded; Search Console ownership and Plausible site creation owner-confirmed; tracking integration pending Phase 1; App Store campaign links verified
**Canonical site:** `https://managestate.app`

This runbook establishes measurement operations without inventing historical
data. On 2026-08-05, the owner confirmed that Google Search Console and web
analytics had never been configured for this site, and supplied nine public App
Store campaign links. On 2026-08-05, the owner then confirmed that the Search
Console domain property was created and DNS-verified and that the Plausible site
was created. No authenticated metrics or historical exports were supplied.
Repository artifacts contain only public observations and sanitized aggregates;
they never contain credentials, raw private exports, PII, or customer property
data.

## Account status

| System | Required target | Current status | What is needed from the owner |
| --- | --- | --- | --- |
| Google Search Console | Domain property `sc-domain:managestate.app` | **Owner-confirmed configured:** the owner reported that the property was created and DNS ownership verified on 2026-08-05. No authenticated export or metrics have been recorded in the repository. | Allow Google to collect data, inspect the authenticated property, and record only values actually exposed. Submit the sitemap after Phase 1 publishes it. |
| Plausible | Site `managestate.app` | **Owner-confirmed created:** the owner reported creating the site on 2026-08-05. No tracking script or historical web-analytics baseline exists yet. | Install and verify the approved script/event configuration during Phase 1; measurement begins from deployment. |
| App Store Connect | ManageState app `6751497970` / bundle `com.managestate.app` | **Campaign links verified:** nine owner-supplied public links resolved to app ID `6751497970` on 2026-08-05. | Map each verified link to its named channel and retain future aggregate campaign results. |

## Search Console procedure

1. The owner confirmed on 2026-08-05 that the Search Console domain property
   `managestate.app` (`sc-domain:managestate.app`) was created and DNS ownership
   verified. Keep the account owner and DNS details in the private operational
   record, not in this public repository.
2. Inspect the current homepage and record indexing status, coverage issues,
   indexed URL count, and excluded URL count from the authenticated interface.
3. After Phase 1 publishes the sitemap, submit
   `https://managestate.app/sitemap-index.xml`. Do not record a successful
   submission until the owner observes it in Search Console.
4. Export the last available 90 days of **Pages** and **Queries** to
   `landing-page/seo-ops/private/`. Keep the raw CSV files ignored and do not
   commit them.
5. Filter query rows with this exact expression:

   ```text
   ^(who|what|where|when|why|how|which|can|do|does|is|are|should|will)\b
   ```

6. Store only aggregate records in
   `landing-page/seo-ops/keywords/search-console-questions.json`:

   ```text
   { query, clicks, impressions, position, sourceWindow }
   ```

   Populate every numeric field from the observed export; do not add a record
   when a source value is unavailable. Remove all other dimensions and any
   sensitive values.
7. The owner confirmed that Search Console was not previously configured. The
   property is now owner-confirmed as created and verified, but no authenticated
   export has been supplied, so the committed question file remains `[]` and
   historical metrics remain unavailable. Record any range Google actually
   exposes later; do not assume it will be zero or backfilled.

## Plausible procedure

1. The owner confirmed on 2026-08-05 that the site domain `managestate.app` was
   created in the owner-controlled Plausible account.
2. Add the privacy-conscious Plausible script to the deployed marketing site
   during the approved site implementation. Confirm that a page view arrives
   without collecting PII or customer property data.
3. Configure the approved outbound event `app_store_click` with page path,
   content cluster, CTA placement, language, and campaign identifier. Verify
   one test event per CTA placement and verify that analytics failure does not
   block page rendering or the App Store link.
4. Grant the baseline operator read access or provide an aggregate export for
   the baseline window. Record observed page views, event counts, and any
   available referral dimensions in the baseline; keep raw exports and tokens
   in `landing-page/seo-ops/private/`.
5. Because the owner confirmed that no analytics was previously installed,
   there is no historical Plausible baseline to recover. Measurement begins
   when the Phase 1 script and events are deployed and verified.

## App Store Connect campaign inventory

The owner supplied these public campaign links. An anonymous check on
2026-08-05 followed each URL to HTTP `200` for ManageState app ID `6751497970`:

| Campaign | Verified public URL |
| --- | --- |
| `website-home` | `https://apps.apple.com/app/apple-store/id6751497970?pt=128092033&ct=website-home&mt=8` |
| `website-features` | `https://apps.apple.com/app/apple-store/id6751497970?pt=128092033&ct=website-features&mt=8` |
| `website-audiences` | `https://apps.apple.com/app/apple-store/id6751497970?pt=128092033&ct=website-audiences&mt=8` |
| `website-comparisons` | `https://apps.apple.com/app/apple-store/id6751497970?pt=128092033&ct=website-comparisons&mt=8` |
| `website-guides` | `https://apps.apple.com/app/apple-store/id6751497970?pt=128092033&ct=website-guides&mt=8` |
| `website-tools` | `https://apps.apple.com/app/apple-store/id6751497970?pt=128092033&ct=website-tools&mt=8` |
| `medium` | `https://apps.apple.com/app/apple-store/id6751497970?pt=128092033&ct=medium&mt=8` |
| `substack` | `https://apps.apple.com/app/apple-store/id6751497970?pt=128092033&ct=substack&mt=8` |
| `youtube` | `https://apps.apple.com/app/apple-store/id6751497970?pt=128092033&ct=youtube&mt=8` |

Phase 1 must map the six website links to their matching content clusters.
External distribution later uses the three channel links. Future aggregate
product-page views, downloads, and attribution should be exported privately and
recorded only as approved aggregates.

## Evidence inventory handoff

The baseline also counts repository records that pass the existing evidence
validator. One public App Store review and three code-verified product claims are
committed; customer testimonials and screenshots remain empty until the owner
supplies provenance and approval. The owner-directed retention exception for the
existing testimonial copy and “Join thousands” CTA claim is documented in
`docs/seo/evidence-register.md` and is not part of the validator-approved counts.
Never fill an evidence count with a guess or publish a generated identity, avatar,
adoption number, or unsupported claim.

## Access and privacy requirements

The owner must provide private access through the normal account invitation or
approved secret/deployment mechanism. Do not send passwords, API keys, private
provider credentials, raw CSV exports, customer property records, or
account-detail screenshots into Git, issue comments, prompts, or public
documentation. Apple campaign `pt` and `ct` query parameters are public
attribution identifiers and may be recorded as part of their public URLs.
Replace inaccessible values with explicit `not configured`, `blocked`, or
`unavailable` wording and preserve the date of the next observation.
