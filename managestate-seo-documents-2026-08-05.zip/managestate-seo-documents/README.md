# ManageState SEO Document Pack

This archive groups the SEO strategy, implementation plans, and completed Phase 0 operational documentation created for `managestate.app`.

## 01 — Strategy

- **SEO growth design:** Approved strategy covering target audiences, English-first rollout, owned-site acquisition pages, external authority channels, and App Store conversion priorities.
- **Master SEO program:** Overall six-phase execution roadmap from baseline setup through controlled automation.

## 02 — Phase plans

- **Phase 0 — Baseline and evidence:** Establishes verified measurement, campaign, review, testimonial, screenshot, and product-claim inputs.
- **Phase 1 — Astro foundation:** Migrates the Vite SPA to Astro and adds technical SEO, Plausible events, App Store attribution, structured data, sitemap, robots, legal links, and CI.
- **Phase 2 — English content:** Plans the first 15 English acquisition pages for landlords with 1–5 properties, with secondary coverage for larger portfolios.
- **Phase 3 — External distribution:** Plans controlled publishing through Medium, Substack, and YouTube to support authority and referral acquisition.
- **Phase 4 — Optimization and localization:** Uses measured English performance to prioritize improvements and later Spanish and Catalan localization.
- **Phase 5 — Controlled automation:** Introduces evidence-gated, quality-controlled SEO automation after the manual system proves effective.

## 03 — Phase 0 operations

- **Measurement setup:** Owner runbook and status for Google Search Console, Plausible, and App Store campaign attribution.
- **Acquisition baseline:** Public technical observations, account setup status, campaign inventory, evidence counts, and known data gaps.
- **Evidence register:** Provenance and publication rules for reviews, testimonials, screenshots, and product claims.
- **SEO operations runbook:** Privacy boundary and storage rules for private analytics exports and committed aggregates.

## Current status

Phase 0 has been implemented and merged locally into `main`. Google Search Console ownership and Plausible site creation are owner-confirmed. The nine App Store campaign links are recorded. Historical analytics are unavailable because tracking was not previously installed.

The next implementation step is **Phase 1: Astro and Technical SEO Foundation**. Plausible script/event deployment and Search Console sitemap submission occur during or after that phase.
