# ManageState SEO Program Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Execute the approved ManageState SEO design through six independently gated phases, from measurement baseline to controlled draft automation.

**Architecture:** Each phase has its own detailed plan and produces a deployable or operationally verifiable outcome. Phases run sequentially; later phases consume explicit artifacts and exit-gate evidence from earlier phases rather than relying on assumptions.

**Tech Stack:** Astro, React, Node.js, Vitest, Tailwind CSS, Google Search Console, Plausible Analytics, App Store Connect, Medium, Substack, YouTube, Anthropic Messages API, GitHub Actions.

## Global Constraints

- Approved design: `docs/superpowers/specs/2026-08-05-managestate-seo-growth-design.md`.
- English first; Spanish second; Catalan third.
- Primary audience: self-managing landlords with one to five properties.
- Primary conversion: Apple App Store download.
- `managestate.app` owns canonical acquisition content.
- No thin location pages, fake proof, invented statistics, duplicate external blasts, or autonomous publishing.
- Every phase stops at its exit gate until failures and residual risks are recorded and resolved.

---

### Task 1: Complete Phase 0 — Baseline and evidence

**Plan:** `docs/superpowers/plans/2026-08-05-seo-phase-0-baseline-evidence.md`

- [ ] Establish validated site/evidence data.
- [ ] Import verifiable App Store evidence.
- [ ] Verify Search Console, Plausible, and App Store campaigns.
- [ ] Record observed baseline and customer-evidence provenance.
- [ ] Pass the Phase 0 exit gate before Astro work begins.

### Task 2: Complete Phase 1 — Astro and technical foundation

**Plan:** `docs/superpowers/plans/2026-08-05-seo-phase-1-astro-foundation.md`

- [ ] Migrate the Vite SPA to static Astro output.
- [ ] Implement canonical metadata, structured data, sitemap, robots, and branded assets.
- [ ] Preserve the visual design while removing unsupported proof and dead CTAs.
- [ ] Add measurable, failure-tolerant App Store links and Plausible events.
- [ ] Add independent landing-site CI and pass the Phase 1 exit gate.

### Task 3: Complete Phase 2 — English acquisition content

**Plan:** `docs/superpowers/plans/2026-08-05-seo-phase-2-english-content.md`

- [ ] Build validated content collections and static route templates.
- [ ] Publish eight feature/audience/comparison pages.
- [ ] Publish five distinct guides.
- [ ] Publish the ROI calculator and rental finance template.
- [ ] Enforce the exact fifteen-page inventory and controlled batch launch.

### Task 4: Complete Phase 3 — External authority distribution

**Plan:** `docs/superpowers/plans/2026-08-05-seo-phase-3-external-distribution.md`

- [ ] Establish a unique, retryable publication ledger.
- [ ] Add deep-link and public-URL verification.
- [ ] Prepare one original pilot each for Medium, Substack, and YouTube.
- [ ] Publish manually at one to two items per week.
- [ ] Measure the 30-day pilot and select the next queue.

### Task 5: Complete Phase 4 — Optimization and localization

**Plan:** `docs/superpowers/plans/2026-08-05-seo-phase-4-optimization-localization.md`

- [ ] Aggregate the first 90 days of English results.
- [ ] Apply isolated technical, snippet, content, or consolidation decisions.
- [ ] Select homepage plus four acquisition winners deterministically.
- [ ] Publish human-reviewed Spanish localizations.
- [ ] Publish independently reviewed Catalan localizations.
- [ ] Verify reciprocal canonicals, `hreflang`, sitemaps, and language analytics.

### Task 6: Complete Phase 5 — Controlled draft automation

**Plan:** `docs/superpowers/plans/2026-08-05-seo-phase-5-controlled-automation.md`

- [ ] Pass the explicit eight-publication automation eligibility gate.
- [ ] Implement a unique topic queue and retryable run state.
- [ ] Generate only evidence-bound, non-production drafts.
- [ ] Block unsafe or duplicate drafts deterministically.
- [ ] Open disabled-by-default weekly human-review pull requests.
- [ ] Observe four runs and keep all publishing/merging manual.

## Program Completion Check

Run the verification commands defined by every phase plan and preserve each phase's review, baseline, release log, and residual-risk record. The program is complete when the multilingual site and manual distribution system are operating measurably; Phase 5 automation is optional and remains disabled unless its eligibility gate passes.
