# ManageState SEO Growth Design

**Date:** 2026-08-05
**Status:** Approved
**Site:** https://managestate.app
**Primary conversion:** Apple App Store download

## 1. Context

ManageState serves self-managing landlords and property investors. Its primary SEO audience is an individual landlord managing one to five properties; investors with roughly five to twenty-five properties are the secondary audience.

The current landing site is a single client-rendered Vite/React page. It has a placeholder title and favicon, no meaningful search metadata, no sitemap or robots file, no structured data, no indexable content routes, and CTA buttons that do not provide a measurable path to the App Store. Its current testimonials and broad adoption claims also need to be replaced or qualified using verified evidence.

The referenced seven-step buy-intent pSEO guide recommends finding real buyer questions, combining parent keywords with audiences and locations, borrowing authority from established publishing platforms, formatting content for search and generative answers, and automating publication. ManageState will adopt the useful parts of that model but will not create thin location pages, duplicate articles, fabricated statistics, or automated promotional spam.

## 2. Goals

1. Make `managestate.app` technically crawlable, indexable, fast, and understandable to search engines and answer engines.
2. Acquire English-speaking landlords who are actively looking for a property-management app or a replacement for spreadsheets.
3. Convert qualified organic visitors into measurable App Store visits and downloads.
4. Establish a repeatable content system that can later expand into Spanish and Catalan.
5. Use selected external platforms to amplify proven content while keeping `managestate.app` as the canonical source and long-term SEO asset.

## 3. Non-goals

- Generating hundreds of city pages whose content is substantially identical.
- Publishing nightly across automated account networks during the initial rollout.
- Migrating or changing the React Native mobile application.
- Building website account creation, checkout, or lead-nurture flows.
- Claiming download counts, customer counts, savings, security guarantees, or performance statistics without verifiable evidence.
- Translating every English page before its topic demonstrates demand or strategic value.

## 4. Audience and positioning

### Primary audience

Self-managing landlords with one to five rental properties who want a simple iPhone app for finances, documents, profitability, tax preparation, and reminders.

### Secondary audience

Growing property investors with approximately five to twenty-five properties who need more control than a spreadsheet provides but do not need enterprise property-management software.

### Positioning

ManageState is the straightforward property-management app for independent landlords who want their rental finances, documents, and portfolio performance in one place without spreadsheet chaos or enterprise complexity.

### Language rollout

1. English is the canonical launch language and receives the first complete content set.
2. Spanish follows after English pages show search demand, conversions, or clear strategic value.
3. Catalan follows Spanish using the same evidence-based selection process.
4. Translations must be localized and editorially reviewed; they must not be raw machine translations.

## 5. Strategic approach

Use a phased hybrid strategy:

1. Build durable technical SEO and high-intent content on `managestate.app`.
2. Publish a controlled first wave of fifteen English acquisition pages.
3. Measure indexing, search visibility, engagement, App Store clicks, and attributed downloads.
4. Repurpose validated topics into original or meaningfully adapted content on selected high-authority platforms.
5. Expand winning topics and translate proven pages.
6. Introduce automation only after the manual workflow repeatedly publishes valid, indexed, converting content.

This approach is preferred over site-only SEO because the domain can benefit from external discovery, and over aggressive parasite pSEO because ManageState does not yet have enough search data, verified proof, or editorial capacity to automate safely.

## 6. Site architecture

### Rendering architecture

Replace the Vite single-page application in `landing-page/` with an Astro static site while preserving the approved visual identity. Astro will render all acquisition content to crawlable HTML at build time. React will remain only as isolated interactive components for calculators, menus, or effects that require client-side behavior.

The deployment target must continue to support a static `dist/` output. Changing hosting providers is outside this design unless the existing provider cannot serve that output, redirects, headers, the sitemap, or the robots file correctly.

### Route model

- `/` — English conversion-focused homepage
- `/features/<feature>/` — product capability pages
- `/for/<audience>/` — audience-specific landing pages
- `/compare/<alternative>/` — accurate alternative and comparison pages
- `/tools/<tool>/` — genuinely useful calculators and templates
- `/guides/<topic>/` — educational and commercial-intent supporting content
- `/es/...` — approved Spanish localizations
- `/ca/...` — approved Catalan localizations

English remains at the root. Spanish and Catalan use language prefixes. Every localized page declares itself and its available equivalents through canonical and `hreflang` annotations.

### Core site components

1. **SEO layout:** Generates titles, descriptions, canonical URLs, Open Graph data, social cards, language annotations, and page-specific structured data.
2. **Content collections:** Store validated frontmatter and body content for features, audiences, comparisons, tools, and guides.
3. **App Store CTA:** Uses one consistent App Store destination contract, descriptive accessible copy, a source identifier, and an outbound click event.
4. **Evidence component:** Displays only verified App Store reviews and customer testimonials, with source records retained for editorial verification.
5. **Related-content component:** Creates intentional internal links within and across topic clusters.
6. **Breadcrumb component:** Provides visible navigation and matching BreadcrumbList structured data.
7. **Localized navigation:** Keeps users and crawlers within the corresponding language tree where a translation exists.

## 7. Technical SEO requirements

Every public page must include:

- One unique, intent-matched title and meta description.
- One self-referencing canonical URL unless an approved canonicalization case applies.
- Correct Open Graph and social metadata.
- One clear H1 and a logical heading hierarchy.
- Descriptive image filenames, dimensions, and alt text.
- Crawlable contextual links rather than JavaScript-only navigation.
- Structured data that accurately describes visible page content.
- An accessible, measurable App Store CTA.

Site-wide requirements:

- XML sitemap containing only canonical, indexable URLs.
- `robots.txt` that references the sitemap and does not block required assets.
- SoftwareApplication schema on the homepage and relevant product pages.
- BreadcrumbList schema on nested routes.
- Article schema on qualifying guides.
- FAQ schema only when the questions and answers are visible and eligible under current search-engine policies.
- Organization schema using verified business details only.
- Redirects from any replaced public URLs to their closest canonical equivalents.
- A branded favicon and social sharing image instead of Vite defaults.
- Production pages that do not depend on JavaScript for their primary copy, links, or metadata.

## 8. Initial English content system

### Keyword selection

Prioritize commercial intent and audience fit over search volume. Initial parent concepts include:

- property management app for small landlords
- landlord expense tracker
- rental income and expense tracker
- rental property document organizer
- rental property ROI calculator
- landlord tax record app
- landlord app instead of Excel
- property management app for iPhone

Modifiers may include `best`, `app`, `tracker`, `for small landlords`, `for 1–5 properties`, `for individual landlords`, `iPhone`, `alternative`, and `instead of spreadsheets`. Comparison terms must be selected only when ManageState can provide a factual, useful comparison.

Location modifiers are excluded from the initial keyword universe. A country or region page becomes eligible only when tax rules, terminology, legal responsibilities, product availability, or landlord workflows make the page materially different.

### First-wave inventory

Publish the following fifteen English acquisition pages in addition to the homepage:

1. `/features/financial-control/`
2. `/features/document-management/`
3. `/features/profitability-roi/`
4. `/features/tax-export/`
5. `/for/small-landlords/`
6. `/for/first-time-landlords/`
7. `/for/growing-property-investors/`
8. `/compare/landlord-app-vs-spreadsheets/`
9. `/guides/property-management-app-for-small-landlords/`
10. `/guides/landlord-expense-tracker/`
11. `/guides/rental-income-expense-tracker/`
12. `/guides/rental-property-document-organizer/`
13. `/guides/landlord-tax-record-app/`
14. `/tools/rental-property-roi-calculator/`
15. `/tools/rental-income-expense-template/`

The exact primary keyword for each URL must be validated against live search results and Search Console data before copy is finalized. Validation may refine wording but must not change the approved audience, intent cluster, or fifteen-page rollout size without a design amendment.

### Page quality contract

Every acquisition page must:

- Answer the target query in the opening paragraph.
- Include a three-to-five-sentence summary that remains useful when quoted independently.
- Address one distinct intent rather than swapping keywords into a shared body template.
- Include original screenshots, calculations, examples, or downloadable utility where appropriate.
- Use FAQs derived from verified Search Console queries, support questions, reviews, or customer interviews when available.
- Link to relevant feature, audience, tool, comparison, and guide pages.
- Use only verified testimonials and factual product claims.
- End with a relevant App Store CTA.
- Receive editorial review before publication.

The current generated testimonial identities, avatar URLs, and “thousands of property owners” claim must not ship unless their authenticity and wording can be substantiated. The available small set of real App Store reviews and customer testimonials is sufficient when presented accurately.

## 9. External authority and discovery

### Channel roles

- **Medium:** Original articles or carefully republished guides. A true republication uses a canonical link to the source page where platform support permits it.
- **Substack:** Practical landlord newsletters that provide standalone value and deep-link to a relevant ManageState guide or tool.
- **YouTube:** Product walkthroughs and landlord tutorials with useful descriptions, transcripts, and relevant destination links.
- **GitHub:** Public assets only when ManageState can release a genuinely useful template, methodology, sample dataset, or tool. GitHub is not an article dumping ground.
- **Social and communities:** Human, context-appropriate answers. Automated promotional posting is prohibited.

Instagram is not an initial SEO publishing priority because its content is less suitable for durable, crawlable acquisition than the selected channels.

### Publication workflow

1. Publish the canonical page on `managestate.app`.
2. Confirm that the page is live, indexable, internally linked, and submitted through the sitemap.
3. Collect initial indexing and engagement signals.
4. Select promising topics for external adaptation.
5. Create platform-specific content rather than copying the same article everywhere.
6. Link to the most relevant destination page, not automatically to the homepage.
7. Record the platform, account, target topic, destination, status, public URL, publication date, and campaign identifier.
8. Verify that the public URL resolves before marking publication successful.
9. Return failed publications to an eligible retry state.
10. Refresh or expand winners and discontinue formats that produce no qualified discovery or conversion signal.

Initial cadence is one to two external publications per week. Nightly automation is not permitted during the first rollout.

## 10. Conversion design

The primary action across the site is `Download ManageState for iPhone` or equivalent intent-specific copy. The site must not introduce account creation, an email gate, or a demo requirement before the App Store destination.

Conversion elements include:

- A working App Store link in the navigation, hero, relevant content sections, and final CTA.
- Verified reviews and product screenshots near high-intent CTAs.
- A consistent outbound event named `app_store_click` with page path, content cluster, CTA placement, language, and campaign identifier.
- App Store Connect campaign links that distinguish major site clusters and external channels.
- No “Start free trial” wording unless that wording accurately matches the App Store product and onboarding flow.

## 11. Analytics and decision flow

### Tooling

- **Google Search Console:** ownership, sitemap submission, query data, indexing, and crawl diagnostics.
- **Plausible Analytics:** privacy-conscious page and custom-event measurement for the marketing site.
- **App Store Connect:** product-page and campaign-attributed download reporting.

The privacy policy must disclose the analytics implementation before tracking is enabled. No personally identifiable customer data or sensitive property data may enter SEO analytics or content-generation workflows.

### Data flow

1. Search Console questions and commercial query patterns enter a controlled keyword backlog.
2. The backlog is scored for intent, audience fit, product fit, evidence availability, differentiation, and editorial effort.
3. Approved topics become content briefs and then Astro content entries.
4. The static build validates and publishes canonical HTML, metadata, internal links, and sitemap entries.
5. Selected successful topics enter the external publication queue.
6. Plausible, Search Console, and App Store Connect results feed the monthly content review.
7. The review expands, refreshes, translates, consolidates, or retires pages based on evidence.

### Scorecard

- **Technical:** valid indexed URLs, excluded URLs, crawl errors, structured-data validity, broken links, and Core Web Vitals.
- **Visibility:** non-branded impressions, ranking queries, average position, and search click-through rate by cluster.
- **Engagement:** engaged visits and navigation into related content.
- **Conversion:** App Store CTA clicks, outbound click-through rate, App Store campaign product-page views, and attributed downloads.
- **Content:** pages gaining impressions, pages with no traction, external URLs indexed, and external sources producing qualified visits.

The first ninety days establish a baseline. Traffic or ranking numbers are not guaranteed. Expansion decisions use observed results rather than arbitrary traffic promises.

## 12. Error handling and operational safeguards

### Site publication

- A failed build, metadata validation, route check, or link check blocks deployment.
- Sitemap entries are generated only from published, canonical, indexable content.
- Missing required frontmatter fails the build rather than producing incomplete metadata.
- Removed pages redirect to the closest useful equivalent; they do not silently become soft 404s.
- Analytics failures must not block page rendering or the App Store link.

### Content operations

- Each keyword/topic has one canonical record to prevent accidental duplicate targeting.
- A topic is marked published only after its public URL returns a successful response and contains the expected canonical URL.
- An external publication failure records its reason and returns the topic to the queue.
- Unsupported claims are removed or held from publication until evidence exists.
- Comparisons record the date and source of factual competitor claims and are reviewed periodically.
- A page that overlaps another page's intent is consolidated or repositioned before publication.

## 13. Testing and release gates

Before each production release:

1. Run the Astro production build and all automated tests.
2. Validate required frontmatter and uniqueness of titles, descriptions, canonicals, and primary headings.
3. Crawl the built site to detect broken internal links, redirect chains, orphaned pages, and non-success responses.
4. Validate the sitemap and robots directives against the production URL policy.
5. Validate JSON-LD syntax and ensure structured data matches visible content.
6. Test canonical and `hreflang` reciprocity when localized pages exist.
7. Verify every App Store CTA destination and `app_store_click` event payload.
8. Run accessibility checks for navigation, headings, image alternatives, keyboard access, and color contrast.
9. Measure representative homepage, guide, comparison, and tool pages for performance regressions.
10. Manually review new content for factual accuracy, intent match, duplication, evidence, and unsupported claims.

No page enters the sitemap merely because a file exists. It must pass the publication status and quality gates.

## 14. Phased rollout

### Phase 0: Baseline and evidence

- Verify Search Console ownership or configure it if absent.
- Record current indexed URLs, queries, impressions, clicks, and crawl issues.
- Configure Plausible and App Store Connect campaign measurement.
- Inventory verified App Store reviews, testimonials, screenshots, and product claims.

### Phase 1: Astro and technical foundation

- Migrate the existing visual landing page to Astro.
- Replace placeholder metadata and assets.
- Implement the route, layout, CTA, structured-data, sitemap, robots, and analytics foundations.
- Remove dead CTA behavior and unsupported proof claims.

### Phase 2: English acquisition content

- Publish the fifteen approved pages in small, internally linked batches.
- Submit and monitor indexing after each batch.
- Improve snippets and page content using early query data without changing intent arbitrarily.

### Phase 3: External distribution

- Adapt validated topics for Medium, Substack, and YouTube at one to two publications per week.
- Add GitHub only when a suitable public utility exists.
- Track publication validity, discovery, referral engagement, and App Store conversion.

### Phase 4: Optimization and localization

- Review the first ninety days by cluster.
- Expand and refresh English winners.
- Localize proven pages into Spanish and then Catalan.
- Introduce country-specific pages only when their content is materially localized.

### Phase 5: Controlled automation

Automation becomes eligible only when the manual process has repeatedly produced valid public URLs, indexed content, editorially acceptable output, and measurable value. Any automated workflow must preserve human approval, unique-topic constraints, publication verification, retry behavior, and evidence rules.

## 15. Primary risks and mitigations

- **Thin or doorway content:** Limit the first wave, require distinct intent and utility, and exclude generic city multiplication.
- **Duplicate external content:** Use platform-specific adaptations and canonicals for true republications.
- **Weak trust signals:** Use the available small set of verified reviews honestly; do not simulate social proof.
- **Inaccurate tax or legal content:** Keep guidance organizational rather than advisory, cite authoritative sources, date-sensitive claims, and include appropriate disclaimers.
- **Premature localization:** Translate only selected proven pages and require human review.
- **Unmeasurable traffic:** Establish Search Console, Plausible events, and App Store campaign links before scaling publication.
- **Automation errors:** Require public URL verification, explicit states, retryable failures, and human editorial approval.
- **Traffic without downloads:** Deep-link each query to the most relevant product capability and measure App Store click-through by cluster.

## 16. Approval decisions

The following decisions were explicitly approved:

- English-first acquisition, followed by Spanish and then Catalan.
- Primary focus on self-managing landlords with one to five properties, with growing investors as a secondary audience.
- Apple App Store download as the primary conversion.
- Search Console status treated as unknown and verified during baseline work.
- Use of the available small set of real App Store reviews and customer testimonials.
- A hybrid owned-site and selective external-authority strategy.
- Astro migration while preserving the existing visual design.
- A fifteen-page English first wave, followed by evidence-based expansion.
- Controlled external publication rather than immediate nightly automation.
